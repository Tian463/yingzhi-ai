export type ConversationMessage = {
  role: "system" | "user" | "assistant";
  content: string;
  imageUrl?: string;
};

export type ConversationRecord = {
  id: string;
  title: string;
  updatedAt: number;
  messages: ConversationMessage[];
};

export function deriveConversationTitle(messages: ConversationMessage[]): string {
  const firstQuestion = messages.find(message => message.role === "user")?.content.trim();
  if (!firstQuestion) return "新的映知对话";
  return firstQuestion.length > 22 ? `${firstQuestion.slice(0, 22)}…` : firstQuestion;
}

export function upsertConversation(
  history: ConversationRecord[],
  record: ConversationRecord
): ConversationRecord[] {
  return [record, ...history.filter(item => item.id !== record.id)]
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, 30);
}
