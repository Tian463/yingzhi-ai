export const ADMIN_ENTRANCE_DURATION_MS = 1550;
export const ADMIN_ENTRANCE_CLASS = "admin-entrance";
export type AdminEntranceTrigger = "unlock" | "refresh";

export function shouldShowAdminEntrance(trigger: AdminEntranceTrigger) {
  return trigger === "unlock";
}

export function shouldRenderAdminEntrance(trigger: AdminEntranceTrigger, prefersReducedMotion: boolean) {
  return shouldShowAdminEntrance(trigger) && !prefersReducedMotion;
}

export function nextDashboardUnlockedState(wasUnlocked: boolean, requestSucceeded: boolean) {
  return wasUnlocked || requestSucceeded;
}
