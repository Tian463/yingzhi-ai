import { describe, expect, it } from "vitest";
import { readPendingTaskMode, serializePendingTask } from "./taskEntry";

describe("任务卡片工作台跳转", () => {
  it("只保存功能模式，不向输入框携带默认提示文字", () => {
    const stored = serializePendingTask("vision");
    expect(stored).toBe('{"mode":"vision"}');
    expect(stored).not.toContain("prompt");
  });

  it("读取合法模式并对旧格式或损坏内容回退到普通聊天", () => {
    expect(readPendingTaskMode('{"mode":"image"}')).toBe("image");
    expect(readPendingTaskMode('{"mode":"video"}')).toBe("chat");
    expect(readPendingTaskMode('{"mode":"model3d"}')).toBe("chat");
    expect(readPendingTaskMode('{"prompt":"不应预填"}')).toBe("chat");
    expect(readPendingTaskMode("not-json")).toBe("chat");
  });
});
