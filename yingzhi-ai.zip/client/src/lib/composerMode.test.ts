import { describe, expect, it } from "vitest";
import { getComposerPlaceholder, isVisionInputLocked, toggleImageCreatorMode } from "./composerMode";

describe("工作台图像创作模式", () => {
  it("可从普通聊天或图文解读切换至图像创作，并可切回普通聊天", () => {
    expect(toggleImageCreatorMode("chat")).toBe("image");
    expect(toggleImageCreatorMode("vision")).toBe("image");
    expect(toggleImageCreatorMode("image")).toBe("chat");
  });

  it("为不同工作模式提供正确的输入提示", () => {
    expect(getComposerPlaceholder("chat")).toBe("发消息");
    expect(getComposerPlaceholder("image")).toContain("生成");
    expect(getComposerPlaceholder("vision")).toContain("解读");
  });

  it("图文解读未上传图片时锁定文字输入，并给出上传提示", () => {
    expect(isVisionInputLocked("vision", false)).toBe(true);
    expect(isVisionInputLocked("vision", true)).toBe(false);
    expect(isVisionInputLocked("chat", false)).toBe(false);
    expect(getComposerPlaceholder("vision", false)).toContain("先上传");
  });
});
