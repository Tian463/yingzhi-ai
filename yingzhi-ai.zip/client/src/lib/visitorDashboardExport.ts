import * as XLSX from "xlsx";

export type VisitorDashboardExportData = {
  totalVisits: number;
  estimatedVisitors: number;
  activeVisitors24Hours: number;
  visitsLast24Hours: number;
  uniqueNetworks: number;
  latestActivity: Date | string | null;
  dailyVisitors: Array<{ day: string; label: string; visitors: number; visits: number }>;
  deviceBreakdown: Array<{ label: string; value: number }>;
  visits: Array<{
    viewedAt: Date | string;
    visitorId: string;
    pagePath: string;
    regionHint: string | null;
    timeZone: string | null;
    language: string | null;
    maskedIp: string;
    deviceType: string;
    operatingSystem: string;
    browser: string;
    referrerHost: string | null;
  }>;
};

function displayTime(value: Date | string | null) {
  return value ? new Date(value).toLocaleString("zh-CN", { hour12: false }) : "暂无";
}

function pageLabel(path: string) {
  return path === "/" ? "官网首页" : path === "/chat" ? "网页工作台" : path === "/app" ? "客户端工作台" : path;
}

export function createVisitorDashboardWorkbook(data: VisitorDashboardExportData) {
  const workbook = XLSX.utils.book_new();
  const summarySheet = XLSX.utils.aoa_to_sheet([
    ["映知 AI 访问概览导出"],
    ["导出时间", new Date().toLocaleString("zh-CN", { hour12: false })],
    [],
    ["指标", "数值"],
    ["估算总访客", data.estimatedVisitors],
    ["24 小时活跃访客", data.activeVisitors24Hours],
    ["累计访问次数", data.totalVisits],
    ["近 24 小时访问", data.visitsLast24Hours],
    ["脱敏网段数", data.uniqueNetworks],
    ["最近活跃", displayTime(data.latestActivity)],
  ]);
  summarySheet["!cols"] = [{ wch: 22 }, { wch: 26 }];
  XLSX.utils.book_append_sheet(workbook, summarySheet, "汇总");

  const trendSheet = XLSX.utils.json_to_sheet(data.dailyVisitors.map(row => ({ 日期: row.day, 显示日期: row.label, 估算访客: row.visitors, 访问次数: row.visits })));
  trendSheet["!cols"] = [{ wch: 14 }, { wch: 12 }, { wch: 14 }, { wch: 14 }];
  XLSX.utils.book_append_sheet(workbook, trendSheet, "每日趋势");

  const deviceSheet = XLSX.utils.json_to_sheet(data.deviceBreakdown.map(row => ({ 设备类型: row.label, 访问次数: row.value })));
  deviceSheet["!cols"] = [{ wch: 16 }, { wch: 14 }];
  XLSX.utils.book_append_sheet(workbook, deviceSheet, "设备分布");

  const visitSheet = XLSX.utils.json_to_sheet(data.visits.map(visit => ({
    时间: displayTime(visit.viewedAt),
    匿名访客: visit.visitorId === "legacy" ? "历史访问" : `访客 ${visit.visitorId.slice(0, 8)}`,
    页面: pageLabel(visit.pagePath),
    地区线索: visit.regionHint || "未提供",
    时区: visit.timeZone || "未提供",
    语言: visit.language || "未提供",
    "IP 网段（脱敏）": visit.maskedIp,
    设备: visit.deviceType,
    系统: visit.operatingSystem,
    浏览器: visit.browser,
    来源: visit.referrerHost || "直接访问",
  })));
  visitSheet["!cols"] = [{ wch: 20 }, { wch: 16 }, { wch: 16 }, { wch: 22 }, { wch: 22 }, { wch: 12 }, { wch: 18 }, { wch: 12 }, { wch: 12 }, { wch: 16 }, { wch: 30 }];
  XLSX.utils.book_append_sheet(workbook, visitSheet, "最近访问明细");
  return workbook;
}

export function downloadVisitorDashboardWorkbook(data: VisitorDashboardExportData) {
  const stamp = new Date().toISOString().replace(/[-:]/g, "").slice(0, 13);
  XLSX.writeFile(createVisitorDashboardWorkbook(data), `映知AI-访问概览-${stamp}.xlsx`, { compression: true });
}
