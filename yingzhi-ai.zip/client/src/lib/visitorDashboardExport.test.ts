import { describe, expect, it } from "vitest";
import { createVisitorDashboardWorkbook } from "./visitorDashboardExport";

describe("访问概览 Excel 导出", () => {
  it("生成包含汇总、趋势、设备与访问明细的工作簿", () => {
    const workbook = createVisitorDashboardWorkbook({
      totalVisits: 8,
      estimatedVisitors: 3,
      activeVisitors24Hours: 2,
      visitsLast24Hours: 5,
      uniqueNetworks: 3,
      latestActivity: "2026-08-25T12:00:00.000Z",
      dailyVisitors: [{ day: "2026-08-25", label: "8/25", visitors: 3, visits: 5 }],
      deviceBreakdown: [{ label: "手机", value: 5 }],
      visits: [{ viewedAt: "2026-08-25T12:00:00.000Z", visitorId: "abc12345-test", pagePath: "/", regionHint: null, timeZone: "Asia/Shanghai", language: "zh-CN", maskedIp: "203.0.113.*", deviceType: "手机", operatingSystem: "Android", browser: "Chrome", referrerHost: null }],
    });

    expect(workbook.SheetNames).toEqual(["汇总", "每日趋势", "设备分布", "最近访问明细"]);
    expect(workbook.Sheets["汇总"]?.A5?.v).toBe("估算总访客");
    expect(workbook.Sheets["最近访问明细"]?.A1?.v).toBe("时间");
  });
});
