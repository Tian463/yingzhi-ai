import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { ADMIN_ENTRANCE_CLASS, ADMIN_ENTRANCE_DURATION_MS, nextDashboardUnlockedState, shouldRenderAdminEntrance, shouldShowAdminEntrance } from "./adminEntrance";

describe("管理员入场特效", () => {
  it("使用稳定的全屏动效标识和短时展示时长", () => {
    expect(ADMIN_ENTRANCE_CLASS).toBe("admin-entrance");
    expect(ADMIN_ENTRANCE_DURATION_MS).toBeGreaterThanOrEqual(1000);
    expect(ADMIN_ENTRANCE_DURATION_MS).toBeLessThanOrEqual(2000);
  });

  it("仅在首次解锁成功时播放，刷新数据不会重复播放", () => {
    expect(shouldShowAdminEntrance("unlock")).toBe(true);
    expect(shouldShowAdminEntrance("refresh")).toBe(false);
  });

  it("在减少动态效果偏好下提供静态降级", () => {
    const styles = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");
    expect(styles).toContain("@media (prefers-reduced-motion: reduce) { .admin-entrance { display: none; } }");
    expect(shouldRenderAdminEntrance("unlock", true)).toBe(false);
    expect(shouldRenderAdminEntrance("unlock", false)).toBe(true);
  });

  it("已解锁后台在刷新请求进行期间保持可见", () => {
    expect(nextDashboardUnlockedState(false, false)).toBe(false);
    expect(nextDashboardUnlockedState(false, true)).toBe(true);
    expect(nextDashboardUnlockedState(true, false)).toBe(true);
  });
});
