export type ComposerMode = "chat" | "image" | "vision";

export function toggleImageCreatorMode(mode: ComposerMode): "chat" | "image" {
  return mode === "image" ? "chat" : "image";
}

export function isVisionInputLocked(mode: ComposerMode, hasSelectedImage: boolean): boolean {
  return mode === "vision" && !hasSelectedImage;
}

export function getComposerPlaceholder(mode: ComposerMode, hasSelectedImage = true): string {
  if (mode === "image") return "描述你想生成的画面…";
  if (isVisionInputLocked(mode, hasSelectedImage)) return "请先上传一张图片，再填写解读问题…";
  if (mode === "vision") return "补充你的解读问题（可选）…";
  return "发消息";
}
