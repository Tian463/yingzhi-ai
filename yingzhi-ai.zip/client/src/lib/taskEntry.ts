export type WorkspaceTaskMode = "chat" | "image" | "vision";

const modes = new Set<WorkspaceTaskMode>(["chat", "image", "vision"]);

export function serializePendingTask(mode?: WorkspaceTaskMode) {
  return JSON.stringify({ mode: mode ?? "chat" });
}

export function readPendingTaskMode(raw: string): WorkspaceTaskMode {
  try {
    const parsed = JSON.parse(raw) as { mode?: unknown };
    return typeof parsed.mode === "string" && modes.has(parsed.mode as WorkspaceTaskMode)
      ? parsed.mode as WorkspaceTaskMode
      : "chat";
  } catch {
    return "chat";
  }
}
