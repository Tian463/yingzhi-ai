import { describe, expect, it } from "vitest";
import { CLIENT_STARTUP_DURATION_MS, shouldShowClientStartup } from "./clientStartup";

describe("客户端启动体验", () => {
  it("在网页、Android 或 Windows 工作台首次打开时显示品牌入场", () => {
    expect(shouldShowClientStartup("/app", false)).toBe(true);
    expect(shouldShowClientStartup("/chat", false)).toBe(true);
    expect(shouldShowClientStartup("/", false)).toBe(false);
  });

  it("遵循减少动态效果偏好", () => {
    expect(shouldShowClientStartup("/app", true)).toBe(false);
    expect(CLIENT_STARTUP_DURATION_MS).toBeLessThanOrEqual(1200);
  });
});
