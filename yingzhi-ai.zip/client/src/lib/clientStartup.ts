export const CLIENT_STARTUP_DURATION_MS = 1080;

export function shouldShowClientStartup(pathname: string, prefersReducedMotion: boolean) {
  return (pathname === "/app" || pathname === "/chat") && !prefersReducedMotion;
}
