import { describe, expect, it } from "vitest";
import { deriveConversationTitle, upsertConversation } from "./conversationHistory";

describe("本地会话历史", () => {
  it("从第一条用户消息生成简洁标题", () => {
    expect(deriveConversationTitle([{ role: "user", content: "请帮我梳理一个项目的研究框架" }])).toBe("请帮我梳理一个项目的研究框架");
    expect(deriveConversationTitle([{ role: "assistant", content: "你好" }])).toBe("新的映知对话");
  });

  it("更新现有会话后会置顶且保留最新记录", () => {
    const history = upsertConversation(
      [{ id: "older", title: "旧对话", updatedAt: 1, messages: [] }],
      { id: "latest", title: "新对话", updatedAt: 2, messages: [] }
    );
    const updated = upsertConversation(history, { id: "older", title: "已更新的旧对话", updatedAt: 3, messages: [] });

    expect(updated).toHaveLength(2);
    expect(updated[0]?.id).toBe("older");
    expect(updated[0]?.title).toBe("已更新的旧对话");
  });
});
