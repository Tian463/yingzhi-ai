import {
  ArrowRight,
  Download,
  FileText,
  Image,
  MessageSquare,
  MonitorDown,
  Palette,
  PenLine,
  Search,
  Smartphone,
  Sparkles,
  ListChecks,
} from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { serializePendingTask } from "@/lib/taskEntry";

const SYMBOL_LOGO = "/manus-storage/yingzhi-transparent-symbol_ad575af6.png";
const ANDROID_APK_URL = "/manus-storage/Yingzhi-AI-1.1.6-Android_7d2a0df2.apk";
const WINDOWS_EXE_URL = "/manus-storage/Yingzhi-AI-1.1.7-Windows_13b85d9f.exe";

type LandingTask = {
  title: string;
  description: string;
  icon: typeof Image;
  mode?: "chat" | "image" | "vision";
  color: string;
};

const tasks: LandingTask[] = [
  { title: "图文解读", description: "上传图片，读懂画面与文字", icon: Image, mode: "vision", color: "from-[#dceeff] to-[#eff7ff] text-[#3977d9]" },
  { title: "文档提炼", description: "让冗长资料变得清晰", icon: FileText, color: "from-[#e4efff] to-[#f2f7ff] text-[#4d75c5]" },
  { title: "深度研究", description: "建立可验证的研究路径", icon: Search, color: "from-[#eeeaff] to-[#f6f4ff] text-[#6c62d2]" },
  { title: "内容创作", description: "将灵感组织成好表达", icon: PenLine, color: "from-[#e4f9ff] to-[#f3fcff] text-[#258eab]" },
  { title: "图像创作", description: "把脑海中的画面变成作品", icon: Palette, mode: "image", color: "from-[#f0ebff] to-[#f8f5ff] text-[#765fd0]" },
  { title: "方案策划", description: "从目标出发，走向行动", icon: ListChecks, color: "from-[#e8f8f2] to-[#f3fcf8] text-[#368d72]" },
];

function BrandLockup() {
  return <div className="flex items-center gap-2.5"><img src={SYMBOL_LOGO} alt="映知 AI" className="size-9 object-contain" /><div className="leading-none"><p className="text-[17px] font-extrabold tracking-[-0.065em] text-[#173b70]">映知 <span className="text-[9px] font-bold tracking-[0.1em] text-[#6390cf]">AI</span></p><p className="mt-1 text-[8px] font-semibold tracking-[0.19em] text-[#95aacf]">JINGTIAN</p></div></div>;
}

export default function Landing() {
  const [, setLocation] = useLocation();
  const [leaving, setLeaving] = useState(false);

  const enterWorkspace = (task?: LandingTask) => {
    if (leaving) return;
    if (task) window.sessionStorage.setItem("yingzhi-pending-task", serializePendingTask(task.mode));
    else window.sessionStorage.removeItem("yingzhi-pending-task");
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setLocation("/chat"); return; }
    setLeaving(true);
    window.setTimeout(() => setLocation("/chat"), 160);
  };

  return (
    <div className={`page-gradient motion-page min-h-[100dvh] overflow-hidden text-[#193a68] ${leaving ? "motion-route-exit" : ""}`} aria-busy={leaving}>
      <div className="gradient-orb gradient-orb-left" /><div className="gradient-orb gradient-orb-right" />
      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6 sm:py-5">
        <BrandLockup />
        <button onClick={() => enterWorkspace()} className="liquid-button group flex items-center gap-2 rounded-2xl px-4 py-2.5 text-xs font-extrabold text-white"><MessageSquare className="size-3.5" />开始聊天<ArrowRight className="size-3.5 transition-transform group-hover:translate-x-0.5" /></button>
      </header>

      <main className="relative z-10 mx-auto max-w-6xl px-4 pb-12 sm:px-6 sm:pb-16">
        <section className="liquid-card hero-gradient mx-auto max-w-5xl overflow-hidden rounded-[34px] px-5 py-12 text-center sm:px-12 sm:py-16">
          <img src={SYMBOL_LOGO} alt="映知 AI 标志" className="mx-auto size-20 object-contain drop-shadow-[0_18px_24px_rgba(31,91,202,.24)] sm:size-24" />
          <p className="mt-6 text-[10px] font-extrabold tracking-[0.2em] text-[#5a81b8] sm:text-[11px]">INTELLIGENCE, REFLECTED.</p>
          <h1 className="mt-3 text-[38px] font-extrabold leading-[1.08] tracking-[-0.07em] text-[#173b70] sm:text-[64px]">映所见，<span className="text-gradient">知所未见</span></h1>
          <p className="mx-auto mt-5 max-w-2xl text-[14px] leading-7 text-[#6f88aa] sm:text-[16px]">从一个问题、一段资料或一个灵感开始。映知陪你把看见的，变成真正的理解。</p>
          <div className="mx-auto mt-7 flex w-fit items-center gap-2 rounded-full border border-white/80 bg-white/50 px-3 py-1.5 text-[10px] font-bold tracking-[0.12em] text-[#7895bc] shadow-sm backdrop-blur"><Sparkles className="size-3 text-[#4d87eb]" />景田科创</div>
          <div className="mx-auto mt-6 grid max-w-lg grid-cols-1 gap-2.5 text-left sm:grid-cols-2"><a href={ANDROID_APK_URL} download className="liquid-card group flex items-center gap-3 rounded-2xl px-4 py-3 transition hover:-translate-y-0.5 hover:shadow-[0_16px_28px_rgba(35,91,182,.16)]"><span className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#dff2ff] to-[#eff9ff] text-[#2585c4]"><Smartphone className="size-4" /></span><span className="min-w-0 flex-1"><span className="block text-xs font-extrabold text-[#315579]">Android 下载</span><span className="mt-0.5 block text-[10px] text-[#88a0bb]">APK · v1.1.6</span></span><Download className="size-4 text-[#5b8fda] transition group-hover:translate-y-0.5" /></a><a href={WINDOWS_EXE_URL} download className="liquid-card group flex items-center gap-3 rounded-2xl px-4 py-3 transition hover:-translate-y-0.5 hover:shadow-[0_16px_28px_rgba(35,91,182,.16)]"><span className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#e7eeff] to-[#f2f6ff] text-[#557bc8]"><MonitorDown className="size-4" /></span><span className="min-w-0 flex-1"><span className="block text-xs font-extrabold text-[#315579]">Windows 下载</span><span className="mt-0.5 block text-[10px] text-[#88a0bb]">EXE · v1.1.7</span></span><Download className="size-4 text-[#5b8fda] transition group-hover:translate-y-0.5" /></a></div>
          <p className="mt-3 text-[10px] font-medium text-[#8ca2bf]">Android 首次安装需允许来自浏览器的应用；Windows 客户端尚未进行代码签名。</p>
        </section>

        <section className="mx-auto mt-6 max-w-5xl"><div className="mb-4 flex items-end justify-between px-1"><div><p className="text-[10px] font-extrabold tracking-[0.17em] text-[#7295c5]">EXPLORE WITH YINGZHI</p><h2 className="mt-1 text-xl font-extrabold tracking-[-0.04em] text-[#294e7a] sm:text-2xl">选择一种开始方式</h2></div><button onClick={() => enterWorkspace()} className="hidden text-xs font-extrabold text-[#3f78d1] transition hover:text-[#215dba] sm:block">打开空白对话 →</button></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-3">{tasks.map(task => { const Icon = task.icon; return <button key={task.title} onClick={() => enterWorkspace(task)} className="liquid-card group rounded-[25px] p-4 text-left transition duration-200 hover:-translate-y-1 hover:shadow-[0_18px_36px_rgba(35,91,182,.16)] active:scale-[0.985] sm:p-5"><span className={`flex size-10 items-center justify-center rounded-2xl bg-gradient-to-br ${task.color} shadow-[0_6px_14px_rgba(45,96,180,.08)]`}><Icon className="size-4" /></span><h3 className="mt-5 text-[15px] font-extrabold tracking-[-0.03em] text-[#315579]">{task.title}</h3><p className="mt-1.5 text-[11px] leading-5 text-[#8099b8]">{task.description}</p><span className="mt-4 block text-[10px] font-bold text-[#5c8bd5] opacity-0 transition group-hover:opacity-100">开始使用 →</span></button>; })}</div></section>
      </main>
    </div>
  );
}
