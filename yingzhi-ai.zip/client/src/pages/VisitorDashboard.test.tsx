// @vitest-environment jsdom
import React from "react";
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ADMIN_ENTRANCE_DURATION_MS } from "@/lib/adminEntrance";
import VisitorDashboard from "./VisitorDashboard";

const mutation = {
  data: undefined as Record<string, unknown> | undefined,
  isPending: false,
  mutate: vi.fn(),
};

vi.mock("@/lib/trpc", () => ({
  trpc: { visitorDashboard: { overview: { useMutation: vi.fn(() => mutation) } } },
}));
vi.mock("@/lib/visitorDashboardExport", () => ({ downloadVisitorDashboardWorkbook: vi.fn() }));
vi.mock("wouter", () => ({ useLocation: () => ["/access", vi.fn()] }));
vi.mock("recharts", () => {
  const Box = ({ children }: { children?: React.ReactNode }) => <div>{children}</div>;
  return { Area: Box, AreaChart: Box, CartesianGrid: Box, Cell: Box, Pie: Box, PieChart: Box, ResponsiveContainer: Box, Tooltip: Box, XAxis: Box, YAxis: Box };
});

const summary = {
  estimatedVisitors: 3,
  activeVisitors24Hours: 2,
  totalVisits: 5,
  visitsLast24Hours: 4,
  uniqueNetworks: 2,
  latestActivity: new Date("2026-08-25T00:00:00.000Z"),
  dailyVisitors: [{ label: "8/25", visitors: 3 }],
  deviceBreakdown: [{ label: "电脑", value: 5 }],
  pageBreakdown: [{ label: "/", value: 5 }],
  sourceBreakdown: [{ label: "3000-is1mebcyasyihfb3egykt-02e6be03.us4.manus.computer", value: 2 }],
  regionBreakdown: [],
  visits: [],
};

function latestSuccessCallback() {
  const [, options] = mutation.mutate.mock.calls.at(-1) as [unknown, { onSuccess?: () => void }];
  return options.onSuccess;
}

function unlockDashboard() {
  fireEvent.change(screen.getByPlaceholderText("请输入管理员密钥"), { target: { value: "jtkcrootaikc888" } });
  fireEvent.click(screen.getByRole("button", { name: "进入" }));
  mutation.data = summary;
  act(() => latestSuccessCallback()?.());
}

describe("VisitorDashboard 管理员交互", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    mutation.data = undefined;
    mutation.isPending = false;
    mutation.mutate.mockReset();
    Object.defineProperty(window, "matchMedia", { configurable: true, value: vi.fn(() => ({ matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn() })) });
  });

  afterEach(() => {
    cleanup();
    vi.clearAllMocks();
    vi.useRealTimers();
  });

  it("首次密钥解锁播放入场特效，然后显示后台", () => {
    render(<VisitorDashboard />);
    unlockDashboard();
    expect(screen.getByTestId("admin-entrance")).not.toBeNull();
    expect(screen.getByText("访问概览")).not.toBeNull();
    act(() => vi.advanceTimersByTime(ADMIN_ENTRANCE_DURATION_MS));
    expect(screen.queryByTestId("admin-entrance")).toBeNull();
  });

  it("刷新数据保持后台可见且不再播放入场特效", () => {
    render(<VisitorDashboard />);
    unlockDashboard();
    act(() => vi.advanceTimersByTime(ADMIN_ENTRANCE_DURATION_MS));
    fireEvent.click(screen.getByRole("button", { name: "刷新数据" }));
    expect(screen.queryByText("ADMIN ONLY")).toBeNull();
    expect(screen.getByText("PRIVATE ANALYTICS")).not.toBeNull();
    act(() => latestSuccessCallback()?.());
    expect(screen.queryByTestId("admin-entrance")).toBeNull();
    expect(screen.queryByText("ADMIN ONLY")).toBeNull();
  });

  it("减少动态效果偏好下不渲染管理员入场叠层", () => {
    Object.defineProperty(window, "matchMedia", { configurable: true, value: vi.fn(() => ({ matches: true, addEventListener: vi.fn(), removeEventListener: vi.fn() })) });
    render(<VisitorDashboard />);
    unlockDashboard();
    expect(screen.queryByTestId("admin-entrance")).toBeNull();
    expect(screen.getByText("PRIVATE ANALYTICS")).not.toBeNull();
  });

  it("长来源地址在统计卡片内截断，不会撑宽移动端布局", () => {
    render(<VisitorDashboard />);
    unlockDashboard();
    const source = screen.getByTitle("3000-is1mebcyasyihfb3egykt-02e6be03.us4.manus.computer");
    expect(source.className).toContain("min-w-0");
    expect(source.className).toContain("truncate");
    expect(source.parentElement?.parentElement?.className).toContain("max-w-full");
  });
});
