import { trpc } from "@/lib/trpc";
import {
  ArrowUp,
  Clock3,
  FileText,
  Image,
  ImagePlus,
  ListChecks,
  Loader2,
  MessageSquarePlus,
  Palette,
  PenLine,
  RotateCcw,
  Search,
  Trash2,
  X,
} from "lucide-react";
import { type FormEvent, type KeyboardEvent, useEffect, useRef, useState } from "react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";
import {
  deriveConversationTitle,
  type ConversationMessage,
  type ConversationRecord,
  upsertConversation,
} from "@/lib/conversationHistory";

type ChatMessage = ConversationMessage;
type Mode = "chat" | "image";
type Task = { title: string; description: string; icon: typeof Image; prompt: string; tint: string; mode?: Mode };

const SYMBOL_LOGO = "/manus-storage/yingzhi-symbol_af296a46.png";
const HISTORY_KEY = "yingzhi-ai-conversation-history-v1";
const SYSTEM_MESSAGE: ChatMessage = { role: "system", content: "映知 AI 是专注任务的中文智能助手。" };

const tasks: Task[] = [
  { title: "图文解读", description: "让画面与文字说清重点", icon: Image, tint: "text-[#3977d9] bg-[#eef6ff]", prompt: "我想看懂一段图文内容。请先说清核心信息，再指出容易忽略的细节，并给我可行动的下一步。" },
  { title: "文档提炼", description: "把厚资料读成清结论", icon: FileText, tint: "text-[#4c75c7] bg-[#f0f6ff]", prompt: "我有一份需要快速读懂的文档。请按核心结论、关键依据、风险或缺口、下一步行动帮我理清。" },
  { title: "深度研究", description: "从纷杂线索找到方向", icon: Search, tint: "text-[#6b64d5] bg-[#f2f1ff]", prompt: "我准备做一项深度研究。请先拆开问题，再给出研究路径、待验证信息和一份可执行的输出提纲。" },
  { title: "内容创作", description: "把灵感变成有力表达", icon: PenLine, tint: "text-[#278aa9] bg-[#eefbff]", prompt: "我有一个还不够成型的想法。请保留核心观点，把它整理成专业、简洁又有说服力的内容。" },
  { title: "图像创作", description: "把脑海中的画面变成作品", icon: Palette, tint: "text-[#765fd0] bg-[#f4f0ff]", prompt: "一张具有高级渐变蓝光感的未来科技海报，极简构图，圆润有机形态，干净留白", mode: "image" },
  { title: "方案策划", description: "把目标与约束变成行动方案", icon: ListChecks, tint: "text-[#3e8d75] bg-[#eefaf5]", prompt: "请把我的目标、约束和已有想法整理为一份可执行方案：包括目标拆解、关键路径、资源安排、风险提示和下一步行动。" },
];

const initialMessage: ChatMessage = {
  role: "assistant",
  content: "你好，我是映知 AI。\n\n把想法、资料或一个还没想明白的问题交给我。我们先看清关键线索，再把答案落到下一步。",
};

const createConversationId = () => `yz-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const createEmptyMessages = (): ChatMessage[] => [SYSTEM_MESSAGE, initialMessage];

function BrandLockup({ compact = false }: { compact?: boolean }) {
  return <div className="flex items-center gap-2.5"><img src={SYMBOL_LOGO} alt="映知 AI" className={compact ? "size-8 object-contain" : "size-10 object-contain"} /><div className="leading-none"><p className={compact ? "text-base font-extrabold tracking-[-0.06em] text-[#173b70]" : "text-lg font-extrabold tracking-[-0.06em] text-[#173b70]"}>映知 <span className="text-[10px] font-bold tracking-[0.1em] text-[#6390cf]">AI</span></p><p className="mt-1 text-[8px] font-semibold tracking-[0.18em] text-[#9aafd0]">JINGTIAN</p></div></div>;
}

function AssistantAvatar() {
  return <img src={SYMBOL_LOGO} alt="映知 AI" className="mt-0.5 size-9 shrink-0 object-contain drop-shadow-[0_6px_10px_rgba(45,98,201,.18)]" />;
}

function readHistory(): ConversationRecord[] {
  if (typeof window === "undefined") return [];
  try { const raw = window.localStorage.getItem(HISTORY_KEY); const value = raw ? JSON.parse(raw) : []; return Array.isArray(value) ? value : []; } catch { return []; }
}

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>(createEmptyMessages);
  const [activeId, setActiveId] = useState(createConversationId);
  const [history, setHistory] = useState<ConversationRecord[]>(readHistory);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("chat");
  const [input, setInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messageEndRef = useRef<HTMLDivElement>(null);

  const chat = trpc.ai.chat.useMutation({
    onSuccess: data => { setMessages(current => [...current, { role: "assistant", content: data.answer }]); setError(null); },
    onError: issue => { setError(issue.message || "暂时无法完成回答，请稍后重试。"); toast.error("映知 AI 暂时无法回答", { description: "稍后再试，或换一种方式描述你的问题。" }); },
  });
  const image = trpc.image.generate.useMutation({
    onSuccess: data => { setMessages(current => [...current, { role: "assistant", content: "图像已经生成。你可以继续描述希望调整的风格、颜色或构图。", imageUrl: data.imageUrl }]); setError(null); },
    onError: issue => { setError(issue.message || "图像生成暂时不可用，请稍后重试。"); toast.error("图像生成失败", { description: "请稍后再试，或简化图像描述。" }); },
  });

  const displayMessages = messages.filter(message => message.role !== "system");
  const hasConversation = displayMessages.some(message => message.role === "user");
  const isWorking = chat.isPending || image.isPending;

  useEffect(() => {
    if (!hasConversation) return;
    const record: ConversationRecord = { id: activeId, title: deriveConversationTitle(messages), updatedAt: Date.now(), messages };
    setHistory(current => upsertConversation(current, record));
  }, [activeId, hasConversation, messages]);
  useEffect(() => { try { window.localStorage.setItem(HISTORY_KEY, JSON.stringify(history)); } catch { /* optional local storage */ } }, [history]);
  useEffect(() => { if (hasConversation) messageEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [hasConversation, isWorking, messages]);

  const submit = (content: string) => {
    const question = content.trim();
    if (!question || isWorking) return;
    const next = [...messages, { role: "user" as const, content: question }];
    setMessages(next); setInput(""); setError(null);
    if (mode === "image") image.mutate({ prompt: question });
    else chat.mutate({ messages: next.filter(message => message.role !== "system").slice(-10).map(message => ({ role: message.role as "user" | "assistant", content: message.content })) });
  };
  const handleSubmit = (event: FormEvent) => { event.preventDefault(); submit(input); };
  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(input); } };
  const startNewChat = () => { setMessages(createEmptyMessages()); setActiveId(createConversationId()); setInput(""); setError(null); setMode("chat"); setHistoryOpen(false); requestAnimationFrame(() => textareaRef.current?.focus()); };
  const selectConversation = (conversation: ConversationRecord) => { setMessages(conversation.messages); setActiveId(conversation.id); setInput(""); setError(null); setMode("chat"); setHistoryOpen(false); };
  const deleteConversation = (id: string) => { setHistory(current => current.filter(item => item.id !== id)); if (id === activeId) startNewChat(); };
  const retry = () => { const latest = [...messages].reverse().find(message => message.role === "user"); if (latest) submit(latest.content); };
  const chooseTask = (task: Task) => { if (task.mode === "image") { setMode("image"); setInput(task.prompt); requestAnimationFrame(() => textareaRef.current?.focus()); return; } submit(task.prompt); };

  return (
    <div className="h-[100dvh] overflow-hidden bg-[radial-gradient(circle_at_50%_0%,#e6f2ff_0%,#f8fbff_42%,#f3f7fd_100%)] text-[#18335a]">
      <header className="h-[68px] shrink-0 border-b border-[#dce8f5]/80 bg-[#f9fcff]/92 backdrop-blur-md sm:h-[76px]">
        <div className="mx-auto flex h-full max-w-6xl items-center justify-between px-4 sm:px-6"><BrandLockup compact /><div className="flex items-center gap-2"><button onClick={() => setHistoryOpen(true)} className="rounded-xl px-2.5 py-2 text-xs font-bold text-[#56769f] transition hover:bg-[#eaf2fc] hover:text-[#295fae]"><Clock3 className="size-4 sm:mr-1.5 sm:inline" /><span className="hidden sm:inline">历史记录</span></button><button onClick={startNewChat} className="flex items-center gap-1.5 rounded-xl bg-[#2868db] px-3 py-2 text-xs font-bold text-white shadow-[0_6px_16px_rgba(40,104,219,.25)] transition hover:bg-[#1f59be] active:scale-[0.97]"><MessageSquarePlus className="size-3.5" /><span className="hidden sm:inline">新对话</span></button></div></div>
      </header>

      {historyOpen && <div className="fixed inset-0 z-50"><button onClick={() => setHistoryOpen(false)} className="absolute inset-0 bg-[#112d5b]/52 backdrop-blur-sm" aria-label="关闭历史记录" /><aside className="absolute bottom-0 left-0 top-0 flex w-[min(360px,calc(100%-22px))] flex-col bg-[#fbfdff] p-5 shadow-[20px_0_60px_rgba(10,35,78,.28)] sm:bottom-5 sm:left-5 sm:top-5 sm:rounded-[24px]"><div className="flex items-center justify-between"><BrandLockup compact /><button onClick={() => setHistoryOpen(false)} className="rounded-lg p-2 text-[#607ea4] hover:bg-[#eff5fc]"><X className="size-4" /></button></div><button onClick={startNewChat} className="mt-6 flex items-center justify-center gap-2 rounded-xl bg-[#2868db] px-4 py-3 text-xs font-bold text-white"><MessageSquarePlus className="size-4" />开始新的对话</button><div className="mt-5 min-h-0 flex-1 overflow-y-auto pr-1"><p className="mb-2 text-[10px] font-bold tracking-[0.13em] text-[#8299ba]">RECENT CONVERSATIONS</p>{history.length === 0 ? <div className="rounded-xl border border-dashed border-[#ccdced] bg-[#f7fbff] p-6 text-center"><Clock3 className="mx-auto size-5 text-[#9db2cc]" /><p className="mt-3 text-xs font-bold text-[#5c759b]">还没有历史对话</p><p className="mt-1 text-[11px] leading-5 text-[#92a4bc]">开始提问后，会话会自动保存在这里。</p></div> : <div className="space-y-2">{history.map(conversation => <div key={conversation.id} className={`group flex items-center gap-1 rounded-xl p-1 ${conversation.id === activeId ? "bg-[#edf5ff]" : "hover:bg-[#f5f8fc]"}`}><button onClick={() => selectConversation(conversation)} className="min-w-0 flex-1 rounded-lg px-2.5 py-2 text-left"><p className="truncate text-xs font-bold text-[#4b668a]">{conversation.title}</p><p className="mt-1 text-[10px] text-[#98a9c0]">{new Date(conversation.updatedAt).toLocaleString("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" })}</p></button><button onClick={() => deleteConversation(conversation.id)} className="rounded-lg p-2 text-[#9aabc0] hover:bg-[#fff0f0] hover:text-[#c66e6e]" aria-label={`删除${conversation.title}`}><Trash2 className="size-3.5" /></button></div>)}</div>}</div></aside></div>}

      <main className="mx-auto flex h-[calc(100dvh-68px)] max-w-6xl flex-col px-4 sm:h-[calc(100dvh-76px)] sm:px-6">
        <section className="min-h-0 flex-1 py-4 sm:py-6">
          <div className="h-full overflow-y-auto overscroll-contain pr-1">
            {!hasConversation ? <div className="mx-auto flex min-h-full max-w-4xl flex-col items-center justify-center pb-4 text-center"><img src={SYMBOL_LOGO} alt="映知 AI" className="size-20 object-contain drop-shadow-[0_12px_20px_rgba(38,98,211,.18)] sm:size-24" /><p className="mt-4 text-[10px] font-bold tracking-[0.16em] text-[#5f86bd]">INTELLIGENCE, REFLECTED.</p><h1 className="mt-3 text-3xl font-extrabold tracking-[-0.055em] text-[#173b70] sm:text-5xl">映所见，<span className="text-[#377ce9]">知所未见</span></h1><p className="mt-3 max-w-lg text-sm leading-7 text-[#7187a6]">从一个问题、一段资料或一个灵感开始。映知陪你把看见的，变成真正的理解。</p><p className="mt-4 text-[11px] font-semibold text-[#8aa0be]">景田科创</p><div className="mt-7 grid w-full grid-cols-2 gap-3 text-left sm:grid-cols-3">{tasks.map(task => { const Icon = task.icon; return <button key={task.title} onClick={() => chooseTask(task)} className="rounded-2xl border border-[#dfe9f5] bg-white/88 p-4 shadow-[0_8px_20px_rgba(46,90,160,.06)] transition hover:-translate-y-0.5 hover:border-[#bcd4f0] hover:shadow-[0_12px_24px_rgba(46,90,160,.11)] active:scale-[0.98]"><span className={`flex size-9 items-center justify-center rounded-xl ${task.tint}`}><Icon className="size-4" /></span><p className="mt-4 text-sm font-extrabold text-[#315579]">{task.title}</p><p className="mt-1 text-[11px] leading-5 text-[#8095b2]">{task.description}</p></button>; })}</div></div> : <div className="mx-auto flex min-h-full max-w-4xl flex-col"><div className="mb-5 flex items-center gap-3"><AssistantAvatar /><div><p className="text-sm font-extrabold text-[#294d79]">映知 AI</p><p className="mt-0.5 text-[10px] font-medium text-[#7a94b8]">{mode === "image" ? "图像创作模式" : "专注对话模式"}</p></div></div><div className="space-y-5 pb-4">{displayMessages.map((message, index) => message.role === "assistant" ? <div key={`${message.role}-${index}`} className="flex items-start gap-3 sm:gap-4"><AssistantAvatar /><div className="min-w-0 flex-1 rounded-[20px] border border-[#dce7f4] bg-white px-4 py-4 shadow-[0_6px_18px_rgba(44,87,152,.06)] sm:px-5"><div className="prose prose-sm max-w-none leading-7 text-[#344d70] prose-headings:mb-3 prose-headings:mt-0 prose-headings:text-[#24466f] prose-p:my-0 prose-p:leading-7 prose-ul:my-3 prose-li:my-1"><Streamdown>{message.content}</Streamdown></div>{message.imageUrl && <img src={message.imageUrl} alt="映知 AI 生成的图像" className="mt-4 w-full rounded-xl border border-[#dde8f7] bg-[#f7fbff] object-cover" />}</div></div> : <div key={`${message.role}-${index}`} className="flex justify-end"><div className="max-w-[82%] rounded-[20px] bg-[#e7f1ff] px-4 py-3 text-sm leading-6 text-[#345173]">{message.content}</div></div>)}{isWorking && <div className="flex items-center gap-3"><AssistantAvatar /><div className="rounded-xl border border-[#dce7f4] bg-white px-4 py-3 text-xs font-semibold text-[#5d7fae] shadow-sm"><Loader2 className="mr-2 inline size-4 animate-spin text-[#4e85e6]" />{mode === "image" ? "正在生成图像…" : "正在梳理答案…"}</div></div>}{error && <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#f3d8d2] bg-[#fff9f8] px-4 py-3 text-xs text-[#9b5d57]"><span>{error}</span><button onClick={retry} className="inline-flex items-center gap-1 font-bold text-[#a34e45] hover:underline"><RotateCcw className="size-3.5" />重试</button></div>}<div ref={messageEndRef} /></div></div>}
          </div>
        </section>

        <section className="shrink-0 border-t border-[#dce8f5] bg-[#f9fcff]/96 pb-3 pt-3 backdrop-blur-md sm:pb-4"><form onSubmit={handleSubmit} className="mx-auto max-w-4xl rounded-2xl border border-[#cdddef] bg-white p-2 shadow-[0_8px_26px_rgba(43,91,167,.12)]"><textarea ref={textareaRef} value={input} onChange={event => setInput(event.target.value)} onKeyDown={handleKeyDown} placeholder={mode === "image" ? "描述你想生成的图像，例如风格、主体、光线和构图…" : "今天，想和映知一起看清什么？"} rows={1} className="block min-h-[48px] max-h-32 w-full resize-none border-0 bg-transparent px-3 pt-2 text-sm leading-6 text-[#2d486c] outline-none placeholder:text-[#9aabc2]" /><div className="flex items-center justify-between px-1"><div className="flex items-center gap-1"><button type="button" onClick={() => setMode("chat")} className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition ${mode === "chat" ? "bg-[#e8f2ff] text-[#3f75cb]" : "text-[#8397b1] hover:bg-[#f1f5fa]"}`}>对话</button><button type="button" onClick={() => setMode("image")} className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition ${mode === "image" ? "bg-[#eeebff] text-[#6657c5]" : "text-[#8397b1] hover:bg-[#f1f5fa]"}`}><ImagePlus className="size-3" />绘图</button></div><button type="submit" disabled={!input.trim() || isWorking} className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-[#2868db] text-white shadow-[0_5px_12px_rgba(40,104,219,.25)] transition hover:bg-[#1f59be] disabled:bg-[#dce6f2] disabled:text-[#97a8bd] active:scale-[0.96]" aria-label={mode === "image" ? "生成图像" : "发送消息"}>{isWorking ? <Loader2 className="size-4 animate-spin" /> : <ArrowUp className="size-4" />}</button></div></form><p className="mt-2 text-center text-[10px] text-[#91a3bc]">景田科创 · 映知 AI 可能会出现错误，请核对重要信息。</p></section>
      </main>
    </div>
  );
}
