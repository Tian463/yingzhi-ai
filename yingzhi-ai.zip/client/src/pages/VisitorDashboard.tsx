import { ADMIN_ENTRANCE_CLASS, ADMIN_ENTRANCE_DURATION_MS, nextDashboardUnlockedState, shouldRenderAdminEntrance, type AdminEntranceTrigger } from "@/lib/adminEntrance";
import { trpc } from "@/lib/trpc";
import { downloadVisitorDashboardWorkbook } from "@/lib/visitorDashboardExport";
import {
  Activity,
  ArrowLeft,
  BarChart3,
  BadgeCheck,
  Clock3,
  Download,
  Globe2,
  KeyRound,
  Laptop,
  LockKeyhole,
  MapPin,
  MonitorSmartphone,
  MousePointerClick,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  Users,
} from "lucide-react";
import React, { useState, type FormEvent, type ReactNode } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";
import { useLocation } from "wouter";

const SYMBOL_LOGO = "/manus-storage/yingzhi-transparent-symbol_ad575af6.png";
const CHART_COLORS = ["#4c91ee", "#7c6ee7", "#45b9bb", "#f0a153", "#e8789c"];

function formatTime(value: Date | string | null | undefined) {
  if (!value) return "暂无";
  return new Date(value).toLocaleString("zh-CN", {
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function pageLabel(path: string) {
  return path === "/" ? "官网首页" : path === "/chat" ? "网页工作台" : path === "/app" ? "客户端工作台" : path;
}

function shortVisitorId(value: string) {
  return value === "legacy" ? "历史访问" : `访客 ${value.slice(0, 8)}`;
}

function BrandLockup() {
  return (
    <div className="flex items-center gap-2.5">
      <img src={SYMBOL_LOGO} alt="映知 AI" className="size-9 object-contain" />
      <div className="leading-none">
        <p className="text-[17px] font-extrabold tracking-[-0.065em] text-[#173b70]">映知 <span className="text-[9px] font-bold tracking-[0.1em] text-[#6390cf]">AI</span></p>
        <p className="mt-1 text-[8px] font-semibold tracking-[0.19em] text-[#95aacf]">ACCESS OVERVIEW</p>
      </div>
    </div>
  );
}

function AdminEntrance() {
  return (
    <div className={ADMIN_ENTRANCE_CLASS} role="status" aria-live="polite" data-testid="admin-entrance">
      <div className="admin-entrance-card">
        <div className="admin-entrance-seal"><ShieldCheck className="size-10 text-white" strokeWidth={1.65} /></div>
        <div className="admin-entrance-chip">JINGTIAN TECHNOLOGY · SECURE ACCESS</div>
        <h2>ADMINISTRATOR</h2>
        <p className="flex items-center gap-2"><BadgeCheck className="size-4" />身份校验通过 · 访问概览已解锁</p>
      </div>
    </div>
  );
}

function BreakdownList({ title, subtitle, items, icon: Icon, empty }: { title: string; subtitle: string; items: Array<{ label: string; value: number }>; icon: typeof Globe2; empty: string }) {
  const max = Math.max(...items.map(item => item.value), 1);
  return (
    <section className="liquid-card min-w-0 overflow-hidden rounded-[26px] p-5">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0"><h2 className="text-sm font-extrabold text-[#315579]">{title}</h2><p className="mt-1 text-[10px] font-semibold text-[#8aa0bc]">{subtitle}</p></div>
        <span className="flex size-8 items-center justify-center rounded-xl bg-[#edf6ff]/80 text-[#4f85d7]"><Icon className="size-4" /></span>
      </div>
      <div className="mt-5 min-w-0 space-y-3">
        {items.length === 0 ? <p className="rounded-2xl bg-white/35 p-4 text-xs leading-5 text-[#7894b7]">{empty}</p> : items.map(item => (
          <div key={item.label} className="min-w-0 max-w-full">
            <div className="flex min-w-0 items-center justify-between gap-3 text-xs"><span className="min-w-0 flex-1 truncate font-bold text-[#527399]" title={item.label}>{item.label}</span><span className="shrink-0 font-extrabold text-[#2e619e]">{item.value}</span></div>
            <div className="mt-1.5 h-1.5 w-full max-w-full overflow-hidden rounded-full bg-[#e6f0fd]"><div className="h-full max-w-full rounded-full bg-gradient-to-r from-[#5a96eb] to-[#84b9f3]" style={{ width: `${Math.max(8, (item.value / max) * 100)}%` }} /></div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ChartFrame({ title, subtitle, icon: Icon, children }: { title: string; subtitle: string; icon: typeof BarChart3; children: ReactNode }) {
  return <section className="liquid-card rounded-[28px] p-5"><div className="flex items-start justify-between gap-3"><div><h2 className="text-sm font-extrabold text-[#315579]">{title}</h2><p className="mt-1 text-[10px] font-semibold text-[#8aa0bc]">{subtitle}</p></div><span className="flex size-8 items-center justify-center rounded-xl bg-[#edf6ff]/80 text-[#4f85d7]"><Icon className="size-4" /></span></div>{children}</section>;
}

function LoginPanel({ accessKey, pending, onChange, onSubmit }: { accessKey: string; pending: boolean; onChange: (value: string) => void; onSubmit: (event: FormEvent) => void }) {
  return (
    <section className="liquid-card hero-gradient mx-auto mt-8 max-w-md rounded-[32px] p-6 sm:mt-14 sm:p-8">
      <div className="flex size-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[#dbeeff] to-[#f0f7ff] text-[#3477d8]"><LockKeyhole className="size-5" /></div>
      <p className="mt-7 text-[10px] font-extrabold tracking-[0.18em] text-[#7295c5]">ADMIN ONLY</p>
      <h1 className="mt-2 text-3xl font-extrabold tracking-[-0.06em] text-[#1d4778]">访问概览</h1>
      <p className="mt-3 text-sm leading-6 text-[#6f88aa]">这是独立的管理员网页。每次打开或刷新都需要重新输入密钥，密钥不会被写入浏览器 Cookie 或本地存储。</p>
      <form onSubmit={onSubmit} className="mt-7">
        <label className="text-[11px] font-extrabold tracking-[0.08em] text-[#527399]">访问密钥</label>
        <div className="mt-2 flex items-center rounded-2xl border border-white/70 bg-white/55 px-3 shadow-[0_12px_28px_rgba(37,91,173,.08)]">
          <KeyRound className="size-4 shrink-0 text-[#6e94c6]" />
          <input value={accessKey} onChange={event => onChange(event.target.value)} type="password" autoComplete="off" placeholder="请输入管理员密钥" className="min-w-0 flex-1 bg-transparent px-3 py-3.5 text-sm font-semibold text-[#315579] outline-none placeholder:text-[#9ab0ca]" />
          <button disabled={!accessKey.trim() || pending} className="liquid-button rounded-xl px-3 py-2 text-xs font-extrabold text-white disabled:opacity-45">{pending ? "验证中" : "进入"}</button>
        </div>
      </form>
      <p className="mt-5 rounded-2xl bg-[#eef6ff]/75 px-3 py-2.5 text-[11px] leading-5 text-[#6280a4]"><ShieldCheck className="mr-1 inline size-3.5 text-[#4282d7]" />地区只显示代理层提供的城市/区域线索或浏览器时区；不保存完整 IP，也不显示精确住址。</p>
    </section>
  );
}

export default function VisitorDashboard() {
  const [, setLocation] = useLocation();
  const [accessKey, setAccessKey] = useState("");
  const [verifiedKey, setVerifiedKey] = useState("");
  const [showAdminEntrance, setShowAdminEntrance] = useState(false);
  const [hasUnlockedDashboard, setHasUnlockedDashboard] = useState(false);
  const overview = trpc.visitorDashboard.overview.useMutation({
    onError: issue => toast.error("无法进入访问概览", { description: issue.message || "请检查密钥后重试。" }),
  });
  const summary = overview.data;
  const unlocked = hasUnlockedDashboard;
  const deviceBreakdown = summary?.deviceBreakdown ?? [];
  const trendData = summary?.dailyVisitors ?? [];
  const submit = (event: FormEvent) => {
    event.preventDefault();
    const key = accessKey.trim();
    if (!key) return;
    setVerifiedKey(key);
    requestOverview(key, "unlock");
  };
  const requestOverview = (key: string, trigger: AdminEntranceTrigger) => overview.mutate({ accessKey: key }, {
    onSuccess: () => {
      setHasUnlockedDashboard(current => nextDashboardUnlockedState(current, true));
      if (trigger === "unlock") setAccessKey("");
      const prefersReducedMotion = typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true;
      if (shouldRenderAdminEntrance(trigger, prefersReducedMotion)) {
        setShowAdminEntrance(true);
        window.setTimeout(() => setShowAdminEntrance(false), ADMIN_ENTRANCE_DURATION_MS);
      }
    },
  });
  const exportWorkbook = () => {
    if (!summary) return;
    downloadVisitorDashboardWorkbook(summary);
    toast.success("Excel 已开始下载");
  };

  return (
    <div className="page-gradient min-h-[100dvh] overflow-x-hidden text-[#193a68]">
      {showAdminEntrance && <AdminEntrance />}
      <div className="gradient-orb gradient-orb-left" />
      <div className="gradient-orb gradient-orb-right" />
      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 sm:py-5">
        <BrandLockup />
        <button onClick={() => setLocation("/")} className="premium-control flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-extrabold text-[#527399]"><ArrowLeft className="size-3.5" />返回官网</button>
      </header>
      <main className="relative z-10 mx-auto min-w-0 max-w-7xl px-4 pb-12 sm:px-6 sm:pb-16">
        {!unlocked ? <LoginPanel accessKey={accessKey} pending={overview.isPending} onChange={setAccessKey} onSubmit={submit} /> : <>
          <section className="liquid-card hero-gradient mt-4 rounded-[32px] p-5 sm:p-7">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
              <div><p className="text-[10px] font-extrabold tracking-[0.18em] text-[#7295c5]">PRIVATE ANALYTICS</p><h1 className="mt-2 text-3xl font-extrabold tracking-[-0.06em] text-[#1d4778] sm:text-4xl">访问概览</h1><p className="mt-2 text-sm text-[#6f88aa]">汇总官网、网页工作台与客户端工作台的真实访问、匿名访客和访问行为。</p></div>
              <div className="flex flex-wrap gap-2"><button onClick={exportWorkbook} disabled={!summary} className="premium-control flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-extrabold text-[#527399] disabled:opacity-45"><Download className="size-3.5" />导出 Excel</button><button onClick={() => verifiedKey && requestOverview(verifiedKey, "refresh")} disabled={overview.isPending || !verifiedKey} className="premium-control flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-extrabold text-[#527399] disabled:opacity-45"><RefreshCw className={`size-3.5 ${overview.isPending ? "animate-spin" : ""}`} />刷新数据</button></div>
            </div>
            <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
              {[{ icon: Users, value: summary?.estimatedVisitors ?? 0, label: "估算总访客", color: "#6b77d5" }, { icon: Activity, value: summary?.activeVisitors24Hours ?? 0, label: "24h 活跃访客", color: "#4a83dc" }, { icon: MousePointerClick, value: summary?.totalVisits ?? 0, label: "累计访问次数", color: "#4c9cab" }, { icon: Clock3, value: summary?.visitsLast24Hours ?? 0, label: "近 24 小时访问", color: "#5a92d9" }, { icon: Globe2, value: summary?.uniqueNetworks ?? 0, label: "脱敏网段数", color: "#7b82d7" }].map(item => <div key={item.label} className="premium-message rounded-2xl p-4"><item.icon className="size-4" style={{ color: item.color }} /><p className="mt-4 text-2xl font-extrabold tracking-[-0.06em] text-[#264f82]">{item.value}</p><p className="mt-1 text-[11px] font-bold text-[#7894b7]">{item.label}</p></div>)}
              <div className="premium-message rounded-2xl p-4"><MonitorSmartphone className="size-4 text-[#3f9bb1]" /><p className="mt-4 text-sm font-extrabold tracking-[-0.04em] text-[#264f82]">{formatTime(summary?.latestActivity)}</p><p className="mt-1 text-[11px] font-bold text-[#7894b7]">最近活跃</p></div>
            </div>
          </section>
          <section className="mt-5 grid gap-5 lg:grid-cols-[1.5fr_1fr]">
            <ChartFrame title="每日访客趋势" subtitle="近 7 日按匿名浏览器标识估算" icon={BarChart3}><div className="mt-5 h-64"><ResponsiveContainer width="100%" height="100%"><AreaChart data={trendData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}><defs><linearGradient id="visitorTrend" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#5798ef" stopOpacity={0.45} /><stop offset="100%" stopColor="#5798ef" stopOpacity={0.03} /></linearGradient></defs><CartesianGrid stroke="#dbe9fb" strokeDasharray="3 3" vertical={false} /><XAxis dataKey="label" tick={{ fill: "#7894b7", fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis allowDecimals={false} tick={{ fill: "#7894b7", fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip contentStyle={{ borderRadius: 14, borderColor: "#d9e8fb", boxShadow: "0 12px 30px rgba(35,86,164,.12)" }} formatter={(value: number) => [value, "访客"]} /><Area type="monotone" dataKey="visitors" stroke="#4c91ee" strokeWidth={3} fill="url(#visitorTrend)" /></AreaChart></ResponsiveContainer></div></ChartFrame>
            <ChartFrame title="设备类型分布" subtitle="全量访问按设备分类" icon={MonitorSmartphone}><div className="mt-3 h-64"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={deviceBreakdown} dataKey="value" nameKey="label" innerRadius={56} outerRadius={86} paddingAngle={4}>{deviceBreakdown.map((item, index) => <Cell key={item.label} fill={CHART_COLORS[index % CHART_COLORS.length]} />)}</Pie><Tooltip contentStyle={{ borderRadius: 14, borderColor: "#d9e8fb", boxShadow: "0 12px 30px rgba(35,86,164,.12)" }} formatter={(value: number) => [value, "访问"]} /><text x="50%" y="47%" textAnchor="middle" fill="#315579" fontSize="23" fontWeight="800">{summary?.totalVisits ?? 0}</text><text x="50%" y="58%" textAnchor="middle" fill="#7894b7" fontSize="11">总访问</text></PieChart></ResponsiveContainer></div><div className="-mt-1 flex flex-wrap justify-center gap-x-4 gap-y-2">{deviceBreakdown.map((item, index) => <span key={item.label} className="flex items-center gap-1.5 text-[11px] font-bold text-[#6380a2]"><i className="size-2 rounded-full" style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }} />{item.label} {item.value}</span>)}</div></ChartFrame>
          </section>
          <section className="mt-5 grid gap-5 lg:grid-cols-3"><BreakdownList title="访问页面" subtitle="访问次数最多的页面" items={summary?.pageBreakdown ?? []} icon={MousePointerClick} empty="还没有页面访问数据。" /><BreakdownList title="来源渠道" subtitle="访问前所在的网站" items={summary?.sourceBreakdown ?? []} icon={Globe2} empty="当前均为直接访问或未提供来源。" /><BreakdownList title="地区线索" subtitle="仅城市/区域级、可能为空" items={summary?.regionBreakdown ?? []} icon={MapPin} empty="部署层未提供地区线索；新访问将尝试记录。" /></section>
          <section className="mt-5 grid gap-5 lg:grid-cols-[0.8fr_1.6fr]">
            <aside className="liquid-card rounded-[28px] p-5"><div className="flex items-center gap-2"><MonitorSmartphone className="size-4 text-[#4f85d7]" /><h2 className="text-sm font-extrabold text-[#315579]">访问设备</h2></div><div className="mt-5 space-y-3">{deviceBreakdown.length === 0 ? <p className="rounded-2xl bg-white/35 p-4 text-xs leading-5 text-[#7894b7]">尚无访问记录。访客打开官网、网页工作台或客户端工作台后，数据会在这里出现。</p> : deviceBreakdown.map(item => <div key={item.label} className="flex items-center justify-between rounded-2xl bg-white/35 px-3.5 py-3"><span className="flex items-center gap-2 text-xs font-bold text-[#527399]">{item.label === "手机" ? <Smartphone className="size-3.5" /> : <Laptop className="size-3.5" />}{item.label}</span><span className="text-sm font-extrabold text-[#2e619e]">{item.value}</span></div>)}</div><div className="mt-6 rounded-2xl bg-[#eef6ff]/75 p-3 text-[11px] leading-5 text-[#6785a8]"><ShieldCheck className="mr-1 inline size-3.5 text-[#4282d7]" />总访客按浏览器本地匿名标识估算。清除浏览器数据、无痕窗口或更换设备会被视为新访客。</div></aside>
            <section className="liquid-card overflow-hidden rounded-[28px]"><div className="flex items-center justify-between px-5 py-4"><div><h2 className="text-sm font-extrabold text-[#315579]">最近访问明细</h2><p className="mt-1 text-[10px] font-semibold text-[#8aa0bc]">最多显示最近 100 条记录</p></div><MapPin className="size-4 text-[#5a8fd4]" /></div><div className="overflow-x-auto border-t border-white/55"><table className="min-w-[980px] w-full text-left"><thead className="bg-white/25 text-[10px] font-extrabold tracking-[0.08em] text-[#7792b4]"><tr><th className="px-5 py-3">时间 / 访客</th><th className="px-4 py-3">页面</th><th className="px-4 py-3">地区线索</th><th className="px-4 py-3">IP 网段</th><th className="px-4 py-3">设备 / 系统</th><th className="px-5 py-3">浏览器 / 来源</th></tr></thead><tbody>{(summary?.visits ?? []).map(visit => <tr key={visit.id} className="border-t border-white/45 text-xs text-[#587797]"><td className="whitespace-nowrap px-5 py-3.5 font-semibold">{formatTime(visit.viewedAt)}<span className="mt-0.5 block text-[10px] font-medium text-[#90a5bf]">{shortVisitorId(visit.visitorId)}</span></td><td className="px-4 py-3.5 font-bold text-[#376797]">{pageLabel(visit.pagePath)}</td><td className="px-4 py-3.5">{visit.regionHint || "未提供"}<span className="block pt-0.5 text-[10px] text-[#8aa0bc]">{visit.timeZone || "无时区"} · {visit.language || "无语言"}</span></td><td className="px-4 py-3.5 font-mono text-[11px]">{visit.maskedIp}</td><td className="px-4 py-3.5">{visit.deviceType} · {visit.operatingSystem}</td><td className="px-5 py-3.5">{visit.browser}{visit.referrerHost ? <span className="block pt-0.5 text-[10px] text-[#8aa0bc]">{visit.referrerHost}</span> : <span className="block pt-0.5 text-[10px] text-[#a0b1c6]">直接访问</span>}</td></tr>)}{summary?.visits.length === 0 && <tr><td colSpan={6} className="px-5 py-12 text-center text-xs text-[#8199b7]">尚无访问记录。请用另一个页面或设备打开映知 AI，再回到这里刷新。</td></tr>}</tbody></table></div></section>
          </section>
        </>}
      </main>
    </div>
  );
}
