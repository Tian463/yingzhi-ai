import { trpc } from "@/lib/trpc";
import { ArrowLeft, ArrowUp, Clock3, ImagePlus, Loader2, MessageSquarePlus, Paperclip, RotateCcw, Sparkles, Trash2, X } from "lucide-react";
import { type FormEvent, type KeyboardEvent, useEffect, useRef, useState } from "react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { deriveConversationTitle, type ConversationMessage, type ConversationRecord, upsertConversation } from "@/lib/conversationHistory";
import { readPendingTaskMode } from "@/lib/taskEntry";
import { getComposerPlaceholder, toggleImageCreatorMode } from "@/lib/composerMode";
import { CLIENT_STARTUP_DURATION_MS, shouldShowClientStartup } from "@/lib/clientStartup";

type ChatMessage = ConversationMessage;
type Mode = "chat" | "image" | "vision";
type SelectedImage = { dataUrl: string; previewUrl: string; fileName: string };

const SYMBOL_LOGO = "/manus-storage/yingzhi-transparent-symbol_ad575af6.png";
const WEB_HISTORY_KEY = "yingzhi-ai-conversation-history-v1";
const CLIENT_HISTORY_KEY = "yingzhi-ai-client-conversation-history-v1";
const SYSTEM_MESSAGE: ChatMessage = { role: "system", content: "映知 AI 是专注任务的中文智能助手。" };
const initialMessage: ChatMessage = { role: "assistant", content: "你好，我是映知 AI。想从什么开始？" };
const createConversationId = () => `yz-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const createEmptyMessages = (): ChatMessage[] => [SYSTEM_MESSAGE, initialMessage];

function readHistory(storageKey: string): ConversationRecord[] {
  if (typeof window === "undefined") return [];
  try { const raw = window.localStorage.getItem(storageKey); const value = raw ? JSON.parse(raw) : []; return Array.isArray(value) ? value : []; } catch { return []; }
}

function AssistantAvatar() {
  return <img src={SYMBOL_LOGO} alt="映知 AI" className="mt-1 size-8 shrink-0 object-contain drop-shadow-[0_10px_15px_rgba(31,91,202,.22)] sm:size-9" />;
}

function ClientStartupOverlay() {
  return <div className="client-startup-overlay" role="status" aria-live="polite">
    <div className="client-startup-halo client-startup-halo-one" /><div className="client-startup-halo client-startup-halo-two" />
    <div className="client-startup-brand"><img src={SYMBOL_LOGO} alt="映知 AI" className="size-16 object-contain drop-shadow-[0_18px_30px_rgba(38,94,195,.3)]" /><p className="mt-5 text-2xl font-extrabold tracking-[-0.06em] text-[#1b4b85]">映知 <span className="text-[#5f93eb]">AI</span></p><p className="mt-2 text-[10px] font-extrabold tracking-[0.24em] text-[#6d91c4]">INTELLIGENCE, REFLECTED.</p><span className="client-startup-line mt-6" /></div>
  </div>;
}

export default function ChatWorkspace() {
  const [location, setLocation] = useLocation();
  const clientMode = location === "/app" || (typeof window !== "undefined" && ["android", "desktop"].includes(new URLSearchParams(window.location.search).get("client") ?? ""));
  const historyKey = clientMode ? CLIENT_HISTORY_KEY : WEB_HISTORY_KEY;
  const [showClientStartup, setShowClientStartup] = useState(() => typeof window !== "undefined" && shouldShowClientStartup(location, window.matchMedia("(prefers-reduced-motion: reduce)").matches));
  const [messages, setMessages] = useState<ChatMessage[]>(createEmptyMessages);
  const [activeId, setActiveId] = useState(createConversationId);
  const [history, setHistory] = useState<ConversationRecord[]>(() => readHistory(historyKey));
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyClosing, setHistoryClosing] = useState(false);
  const [mode, setMode] = useState<Mode>("chat");
  const [input, setInput] = useState("");
  const [selectedImage, setSelectedImage] = useState<SelectedImage | null>(null);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messageEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const chat = trpc.ai.chat.useMutation({
    onSuccess: data => { setMessages(current => [...current, { role: "assistant", content: data.answer }]); setError(null); },
    onError: issue => { setError(issue.message || "暂时无法完成回答，请稍后重试。"); toast.error("映知 AI 暂时无法回答", { description: "请稍后再试。" }); },
  });
  const image = trpc.image.generate.useMutation({
    onSuccess: data => { setMessages(current => [...current, { role: "assistant", content: "图像已经生成。", imageUrl: data.imageUrl }]); setError(null); },
    onError: issue => { setError(issue.message || "图像生成暂时不可用，请稍后重试。"); toast.error("图像生成失败", { description: "请稍后再试。" }); },
  });
  const visual = trpc.visual.analyze.useMutation();

  const displayMessages = messages.filter(message => message.role !== "system");
  const isWorking = chat.isPending || image.isPending || visual.isPending;
  const visionRequiresImage = mode === "vision" && !selectedImage;

  useEffect(() => {
    const raw = window.sessionStorage.getItem("yingzhi-pending-task");
    if (!raw) return;
    try { setMode(readPendingTaskMode(raw)); setInput(""); } finally { window.sessionStorage.removeItem("yingzhi-pending-task"); }
  }, []);
  useEffect(() => {
    if (!showClientStartup) return;
    const timer = window.setTimeout(() => setShowClientStartup(false), CLIENT_STARTUP_DURATION_MS);
    return () => window.clearTimeout(timer);
  }, [showClientStartup]);
  useEffect(() => {
    if (!messages.some(message => message.role === "user")) return;
    setHistory(current => upsertConversation(current, { id: activeId, title: deriveConversationTitle(messages), updatedAt: Date.now(), messages }));
  }, [activeId, messages]);
  useEffect(() => { try { window.localStorage.setItem(historyKey, JSON.stringify(history)); } catch { /* optional */ } }, [history, historyKey]);
  useEffect(() => { messageEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages, isWorking]);

  const uploadImage = (file: File) => {
    if (!file.type.match(/^image\/(jpeg|png|webp|gif)$/)) { toast.error("请选择 PNG、JPG、WEBP 或 GIF 图片"); return; }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") return;
      setSelectedImage(current => { if (current?.previewUrl.startsWith("blob:")) URL.revokeObjectURL(current.previewUrl); return { dataUrl: reader.result as string, previewUrl: URL.createObjectURL(file), fileName: file.name }; });
      setMode("vision"); setError(null);
    };
    reader.readAsDataURL(file);
  };

  const toggleImageCreator = () => {
    setSelectedImage(current => {
      if (current?.previewUrl.startsWith("blob:")) URL.revokeObjectURL(current.previewUrl);
      return null;
    });
    setMode(current => toggleImageCreatorMode(current));
    setError(null);
  };

  const submit = (content: string) => {
    const question = content.trim();
    if (isWorking) return;
    if (mode === "vision") {
      if (!selectedImage) { setError("请先选择一张图片，再开始图文解读。"); return; }
      const attachment = selectedImage;
      const next = [...messages, { role: "user" as const, content: question || "请解读这张图片。", imageUrl: attachment.previewUrl }];
      setMessages(next); setInput(""); setSelectedImage(null); setError(null);
      visual.mutate({ dataUrl: attachment.dataUrl, fileName: attachment.fileName, prompt: question }, {
        onSuccess: data => {
          setMessages(current => [...current.map(message => message.imageUrl === attachment.previewUrl ? { ...message, imageUrl: data.imageUrl } : message), { role: "assistant", content: data.answer }]);
          if (attachment.previewUrl.startsWith("blob:")) URL.revokeObjectURL(attachment.previewUrl);
          setError(null);
        },
        onError: issue => { setError(issue.message || "图文解读暂时不可用，请稍后重试。"); toast.error("图文解读失败", { description: "请稍后再试。" }); },
      });
      return;
    }
    if (!question) return;
    const next = [...messages, { role: "user" as const, content: question }];
    setMessages(next); setInput(""); setError(null);
    if (mode === "image") image.mutate({ prompt: question });
    else chat.mutate({ messages: next.filter(message => message.role !== "system").slice(-10).map(message => ({ role: message.role as "user" | "assistant", content: message.content })) });
  };
  const handleSubmit = (event: FormEvent) => { event.preventDefault(); submit(input); };
  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(input); } };
  const startNewChat = () => { setMessages(createEmptyMessages()); setActiveId(createConversationId()); setInput(""); setSelectedImage(null); setError(null); setMode("chat"); setHistoryOpen(false); requestAnimationFrame(() => textareaRef.current?.focus()); };
  const selectConversation = (conversation: ConversationRecord) => { setMessages(conversation.messages); setActiveId(conversation.id); setInput(""); setError(null); setMode("chat"); setHistoryOpen(false); };
  const deleteConversation = (id: string) => { setHistory(current => current.filter(item => item.id !== id)); if (id === activeId) startNewChat(); };
  const retry = () => { const latest = [...messages].reverse().find(message => message.role === "user"); if (latest) submit(latest.content); };
  const closeHistory = () => {
    if (!historyOpen || historyClosing) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setHistoryOpen(false); return; }
    setHistoryClosing(true);
    window.setTimeout(() => { setHistoryOpen(false); setHistoryClosing(false); }, 180);
  };

  return <div className="chat-premium-bg motion-page h-[100dvh] overflow-hidden text-[#1d385e]">{showClientStartup && <ClientStartupOverlay />}
    <header className="app-safe-header relative z-20 border-b border-white/28 bg-[#eaf3ff]/22 backdrop-blur-2xl"><div className="mx-auto flex h-[66px] max-w-5xl items-center justify-between px-4 sm:h-[72px] sm:px-6">{clientMode ? <span className="w-12" aria-hidden="true" /> : <button onClick={() => setLocation("/")} className="flex items-center gap-2 rounded-xl px-2 py-2 text-xs font-bold text-[#6885a9] transition hover:bg-white/18 hover:text-[#285d9e]"><ArrowLeft className="size-4" />首页</button>}<div className="absolute left-1/2 -translate-x-1/2 text-center"><p className="text-[14px] font-extrabold tracking-[-0.04em] text-[#2a527f]">映知</p><p className="mt-0.5 text-[8px] font-semibold tracking-[0.16em] text-[#88a1bf]">AI ASSISTANT</p></div><div className="flex items-center gap-2"><button onClick={() => { setHistoryClosing(false); setHistoryOpen(true); }} className="premium-control rounded-xl p-2 text-[#527399] transition hover:-translate-y-0.5 hover:text-[#235da6]" aria-label="历史记录"><Clock3 className="size-4" /></button><button onClick={startNewChat} className="premium-control flex size-9 items-center justify-center rounded-xl text-[#2d67b7] transition hover:-translate-y-0.5" aria-label="新对话"><MessageSquarePlus className="size-3.5" /></button></div></div></header>
    {historyOpen && <div className="fixed inset-0 z-50"><button onClick={closeHistory} className={`history-backdrop absolute inset-0 bg-[#0f2546]/58 backdrop-blur-md ${historyClosing ? "is-closing" : ""}`} aria-label="关闭历史记录" /><aside className={`premium-drawer absolute bottom-0 left-0 top-0 flex w-[min(360px,calc(100%-18px))] flex-col p-5 sm:bottom-5 sm:left-5 sm:top-5 sm:rounded-[26px] ${historyClosing ? "drawer-out" : "drawer-in"}`}><div className="flex items-center justify-between"><div><p className="text-base font-extrabold tracking-[-0.04em] text-[#284e7d]">历史记录</p><p className="mt-1 text-[10px] font-semibold tracking-[0.04em] text-[#8398b5]">保存在当前浏览器</p></div><button onClick={closeHistory} className="premium-control rounded-xl p-2 text-[#6b86a7]"><X className="size-4" /></button></div><button onClick={startNewChat} className="premium-action mt-6 flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-xs font-extrabold text-white"><MessageSquarePlus className="size-4" />开始新的对话</button><div className="mt-5 min-h-0 flex-1 overflow-y-auto pr-1"><p className="mb-2 text-[10px] font-extrabold tracking-[0.15em] text-[#7894b9]">RECENT CONVERSATIONS</p>{history.length === 0 ? <div className="premium-message rounded-2xl p-7 text-center"><Clock3 className="mx-auto size-5 text-[#8ea6c4]" /><p className="mt-3 text-xs font-extrabold text-[#5e789e]">还没有历史对话</p></div> : <div className="space-y-2">{history.map(conversation => <div key={conversation.id} className={`group flex items-center gap-1 rounded-xl p-1 ${conversation.id === activeId ? "bg-white/25" : "hover:bg-white/14"}`}><button onClick={() => selectConversation(conversation)} className="min-w-0 flex-1 rounded-lg px-2.5 py-2 text-left"><p className="truncate text-xs font-extrabold text-[#45668f]">{conversation.title}</p><p className="mt-1 text-[10px] text-[#90a4c0]">{new Date(conversation.updatedAt).toLocaleString("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" })}</p></button><button onClick={() => deleteConversation(conversation.id)} className="rounded-lg p-2 text-[#9aabc0] hover:bg-[#fff0f0] hover:text-[#c66e6e]" aria-label={`删除${conversation.title}`}><Trash2 className="size-3.5" /></button></div>)}</div>}</div></aside></div>}
    <main className="app-safe-main mx-auto flex max-w-5xl flex-col px-4 sm:px-6"><section className="chat-scroll min-h-0 flex-1 py-5 sm:py-7"><div className="mx-auto max-w-3xl space-y-5 sm:space-y-6">{displayMessages.map((message, index) => message.role === "assistant" ? <div key={`${message.role}-${index}`} className="message-in flex items-start gap-3 sm:gap-4"><AssistantAvatar /><div className="premium-assistant-content min-w-0 flex-1 rounded-[20px] px-4 py-3.5 sm:px-5 sm:py-4"><div className="prose prose-sm max-w-none leading-7 text-[#30486a] prose-headings:mb-3 prose-headings:mt-0 prose-headings:text-[#203e68] prose-p:my-0 prose-p:leading-7 prose-ul:my-3 prose-li:my-1"><Streamdown>{message.content}</Streamdown></div>{message.imageUrl && <img src={message.imageUrl} alt="映知 AI 生成的图像" className="mt-4 w-full rounded-2xl border border-white/45 object-cover shadow-[0_15px_32px_rgba(22,69,137,.14)]" />}</div></div> : <div key={`${message.role}-${index}`} className="message-in flex justify-end"><div className="premium-user-message max-w-[76%] rounded-[20px] px-4 py-2.5 text-[14px] leading-6 text-[#23476e]">{message.imageUrl && <img src={message.imageUrl} alt="已上传待解读图片" className="mb-2 max-h-60 w-full rounded-xl object-cover" />}{message.content}</div></div>)}{isWorking && <div className="message-in flex items-center gap-3"><AssistantAvatar /><div className="premium-assistant-content rounded-2xl px-4 py-3 text-xs font-bold text-[#527399]"><Loader2 className="mr-2 inline size-4 animate-spin text-[#3b82e5]" />{mode === "image" ? "正在生成图像…" : mode === "vision" ? "正在解读图片…" : "正在思考…"}</div></div>}{error && <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#f4d7d3] bg-[#fff9f8] px-4 py-3 text-xs text-[#995b55]"><span>{error}</span><button onClick={retry} className="inline-flex items-center gap-1 font-extrabold text-[#a34e45] hover:underline"><RotateCcw className="size-3.5" />重试</button></div>}<div ref={messageEndRef} /></div></section><section className="shrink-0 border-t border-white/22 bg-[#dcecff]/18 px-0 pb-[max(0.8rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-2xl sm:py-4"><form onSubmit={handleSubmit} className="premium-composer mx-auto max-w-3xl rounded-[22px] p-2.5"><input ref={imageInputRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden" onChange={event => { const file = event.target.files?.[0]; if (file) uploadImage(file); event.currentTarget.value = ""; }} />{selectedImage && <div className="mx-1 flex items-center gap-2 rounded-xl bg-white/38 p-2"><img src={selectedImage.previewUrl} alt="待解读图片" className="size-10 rounded-lg object-cover" /><span className="min-w-0 flex-1 truncate text-[11px] font-bold text-[#55769d]">{selectedImage.fileName}</span><button type="button" onClick={() => { if (selectedImage.previewUrl.startsWith("blob:")) URL.revokeObjectURL(selectedImage.previewUrl); setSelectedImage(null); setMode("chat"); }} className="rounded-lg p-1.5 text-[#7190b2] hover:bg-white/55" aria-label="移除图片"><X className="size-3.5" /></button></div>}{visionRequiresImage && <p className="mx-2 mt-1 rounded-xl bg-[#eef6ff]/70 px-3 py-2 text-[11px] font-semibold text-[#51769e]">图文解读需要先上传一张图片，上传后才能输入问题并发送。</p>}<textarea ref={textareaRef} value={input} onChange={event => setInput(event.target.value)} onKeyDown={handleKeyDown} disabled={visionRequiresImage} placeholder={getComposerPlaceholder(mode, Boolean(selectedImage))} rows={1} className="block min-h-[50px] max-h-32 w-full resize-none border-0 bg-transparent px-3.5 pt-2.5 text-[14px] leading-6 tracking-[0.01em] text-[#254568] outline-none placeholder:text-[#8ca3c0] disabled:cursor-not-allowed disabled:opacity-55" /><div className="flex items-center justify-between px-1"><div className="flex items-center gap-1"><button type="button" onClick={() => imageInputRef.current?.click()} className="flex items-center gap-1.5 rounded-xl px-2 py-1.5 text-[10px] font-semibold text-[#7c96b5] transition hover:bg-white/35 hover:text-[#396eaa]" aria-label="上传图片解读"><Paperclip className="size-3.5" />{mode === "vision" ? <><ImagePlus className="size-3.5" />上传图片</> : "添加图片"}</button><button type="button" onClick={toggleImageCreator} className={`flex items-center gap-1.5 rounded-xl px-2 py-1.5 text-[10px] font-semibold transition ${mode === "image" ? "bg-[#dcecff]/80 text-[#2769bf] shadow-[0_5px_14px_rgba(49,109,192,.16)]" : "text-[#7c96b5] hover:bg-white/35 hover:text-[#396eaa]"}`} aria-label={mode === "image" ? "切换到普通对话" : "切换到图像创作"}><Sparkles className="size-3.5" />{mode === "image" ? "对话" : "图像创作"}</button></div><button type="submit" disabled={(mode === "vision" ? !selectedImage : !input.trim()) || isWorking} className="premium-action flex size-10 shrink-0 items-center justify-center rounded-2xl text-white disabled:opacity-45" aria-label="发送消息">{isWorking ? <Loader2 className="size-4 animate-spin" /> : <ArrowUp className="size-4" />}</button></div></form><p className="mt-2 text-center text-[10px] font-medium text-[#859bb5]">景田科创 · 映知 AI 可能会出现错误，请核对重要信息。</p></section></main></div>;
}
