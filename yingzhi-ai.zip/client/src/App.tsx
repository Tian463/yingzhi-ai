import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import { useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Landing from "./pages/Landing";
import ChatWorkspace from "./pages/ChatWorkspace";
import VisitorDashboard from "./pages/VisitorDashboard";

function PublicVisitRecorder() {
  const [location] = useLocation();
  const record = trpc.visitorDashboard.record.useMutation();

  useEffect(() => {
    if (location !== "/" && location !== "/chat" && location !== "/app") return;
    const visitedKey = `yingzhi-visit:${location}`;
    if (window.sessionStorage.getItem(visitedKey)) return;
    window.sessionStorage.setItem(visitedKey, "1");
    const visitorStorageKey = "yingzhi-visitor-id-v1";
    let visitorId = window.localStorage.getItem(visitorStorageKey);
    if (!visitorId) {
      visitorId = window.crypto?.randomUUID?.() ?? `yz-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
      window.localStorage.setItem(visitorStorageKey, visitorId);
    }
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    record.mutate({ pagePath: location, visitorId, timeZone, language: navigator.language });
  }, [location, record]);

  return null;
}

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Landing} />
      <Route path={"/chat"} component={ChatWorkspace} />
      <Route path={"/app"} component={ChatWorkspace} />
      <Route path={"/access"} component={VisitorDashboard} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <PublicVisitRecorder />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
