import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { appRouter } from "./routers";

function createContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("访问概览密钥验证", () => {
  it("只接受已配置的管理员密钥，并且不创建跨页面会话 Cookie", async () => {
    const configuredKey = process.env.VISITOR_DASHBOARD_KEY;
    expect(configuredKey).toEqual(expect.any(String));
    const ctx = createContext();

    const result = await appRouter.createCaller(ctx).visitorDashboard.overview({ accessKey: configuredKey! });

    expect(result).toHaveProperty("totalVisits");
  });

  it("拒绝错误密钥", async () => {
    const configuredKey = process.env.VISITOR_DASHBOARD_KEY;
    expect(configuredKey).toEqual(expect.any(String));
    const ctx = createContext();

    await expect(appRouter.createCaller(ctx).visitorDashboard.overview({ accessKey: `${configuredKey}-invalid` })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
