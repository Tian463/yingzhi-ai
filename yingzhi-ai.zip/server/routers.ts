import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import {
  buildYingzhiMessages,
  extractAssistantText,
  isJingtianTechnologyQuestion,
  JINGTIAN_TECHNOLOGY_PROFILE,
} from "./ai";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { createYingzhiImage } from "./image";
import { analyzeUploadedImage, getRequestOrigin } from "./vision";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { isValidDashboardKey } from "./visitorDashboardAccess";
import { getVisitorOverview, recordVisitorEvent } from "./db";
import { buildVisitorEvent } from "./visitorAnalytics";

const chatInput = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().trim().min(1).max(4000),
      })
    )
    .min(1)
    .max(12),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  visitorDashboard: router({
    record: publicProcedure
      .input(z.object({
        pagePath: z.enum(["/", "/chat", "/app"]),
        visitorId: z.string().trim().min(12).max(80),
        timeZone: z.string().trim().max(64).optional(),
        language: z.string().trim().max(32).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        try {
          await recordVisitorEvent(buildVisitorEvent(ctx.req, input));
        } catch (error) {
          console.warn("[Visitor dashboard] Failed to record visit", error);
        }
        return { recorded: true };
      }),
    overview: publicProcedure.input(z.object({ accessKey: z.string().min(1).max(128) })).mutation(async ({ input }) => {
      if (!isValidDashboardKey(input.accessKey)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "请输入访问密钥。" });
      }
      return getVisitorOverview();
    }),
  }),
  ai: router({
    chat: publicProcedure.input(chatInput).mutation(async ({ input }) => {
      const latestUserMessage = [...input.messages]
        .reverse()
        .find(message => message.role === "user");

      if (
        latestUserMessage &&
        isJingtianTechnologyQuestion(latestUserMessage.content)
      ) {
        return {
          answer: JINGTIAN_TECHNOLOGY_PROFILE,
          model: "yingzhi-brand-profile",
          usage: null,
        };
      }

      try {
        const result = await invokeLLM({
          messages: buildYingzhiMessages(input.messages),
          maxTokens: 1200,
        });
        const answer = extractAssistantText(result);
        if (!answer) throw new Error("模型未返回可呈现的内容");

        return {
          answer,
          model: result.model,
          usage: result.usage?.total_tokens ?? null,
        };
      } catch (error) {
        console.error("[Yingzhi AI] Chat completion failed", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "映知 AI 暂时无法完成回答，请稍后重试。",
        });
      }
    }),
  }),
  image: router({
    generate: publicProcedure
      .input(z.object({ prompt: z.string().trim().min(2).max(2000) }))
      .mutation(async ({ input }) => {
        try {
          const result = await createYingzhiImage(input.prompt);
          if (!result.url) throw new Error("图像服务未返回可展示的结果");
          return { imageUrl: result.url, model: "gpt-image-2" };
        } catch (error) {
          console.error("[Yingzhi AI] Image generation failed", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "图像生成暂时不可用，请稍后再试。",
          });
        }
      }),
  }),
  visual: router({
    analyze: publicProcedure
      .input(z.object({
        dataUrl: z.string().min(32).max(30_000_000),
        fileName: z.string().trim().max(100).optional(),
        prompt: z.string().trim().max(2000).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        try {
          return await analyzeUploadedImage({
            ...input,
            publicOrigin: getRequestOrigin(ctx.req),
          });
        } catch (error) {
          console.error("[Yingzhi AI] Visual analysis failed", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: error instanceof Error ? error.message : "图文解读暂时不可用，请稍后再试。",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
