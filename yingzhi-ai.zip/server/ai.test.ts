import { describe, expect, it } from "vitest";
import {
  buildYingzhiMessages,
  extractAssistantText,
  isJingtianTechnologyQuestion,
  JINGTIAN_TECHNOLOGY_PROFILE,
} from "./ai";

describe("映知 AI 对话编排", () => {
  it("会在会话前注入聚焦任务与避免臆造的系统要求", () => {
    const messages = buildYingzhiMessages([
      { role: "user", content: "  帮我梳理一份研究提纲  " },
    ]);

    expect(messages[0]).toMatchObject({ role: "system" });
    expect(String(messages[0]?.content)).toContain("不编造资料");
    expect(messages[1]).toEqual({
      role: "user",
      content: "帮我梳理一份研究提纲",
    });
  });

  it("会从纯文本或多段文本模型返回中提取可呈现的内容", () => {
    expect(
      extractAssistantText({
        choices: [{ message: { role: "assistant", content: "  简洁结论  " } }],
      })
    ).toBe("简洁结论");

    expect(
      extractAssistantText({
        choices: [
          {
            message: {
              role: "assistant",
              content: [
                { type: "text", text: "第一部分" },
                { type: "text", text: "第二部分" },
              ],
            },
          },
        ],
      })
    ).toBe("第一部分\n第二部分");
  });

  it("遇到景田科创相关询问时可识别并保留官方介绍", () => {
    expect(isJingtianTechnologyQuestion("请介绍景田科创")).toBe(true);
    expect(isJingtianTechnologyQuestion("What is JINGTIAN TECHNOLOGY?")).toBe(true);
    expect(isJingtianTechnologyQuestion("请帮我提炼一份资料")).toBe(false);
    expect(JINGTIAN_TECHNOLOGY_PROFILE).toContain("跨域数字创新实践团体");
    expect(JINGTIAN_TECHNOLOGY_PROFILE).toContain("jtkcxt@gmail.com");
  });
});
