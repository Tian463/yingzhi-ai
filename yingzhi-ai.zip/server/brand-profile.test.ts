import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("景田科创品牌问答", () => {
  it("直接返回已核定的官方介绍，而不调用通用模型回答", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.ai.chat({
      messages: [{ role: "user", content: "请介绍一下景田科创" }],
    });

    expect(result.model).toBe("yingzhi-brand-profile");
    expect(result.answer).toContain("跨域数字创新实践团体");
    expect(result.answer).toContain("技术赋能创意，创意驱动产品");
    expect(result.answer).toContain("jtkcxt@gmail.com");
  });
});
