import { describe, expect, it } from "vitest";
import { buildDailyVisitorSeries, classifyVisitorAgent, getCoarseRegionHint, getReferrerHost, maskIpAddress } from "./visitorAnalytics";

describe("访问概览数据最小化", () => {
  it("只保留 IPv4 的脱敏网段和 IPv6 的局部前缀", () => {
    expect(maskIpAddress("203.0.113.82")).toBe("203.0.113.*");
    expect(maskIpAddress("::ffff:198.51.100.9")).toBe("198.51.100.*");
    expect(maskIpAddress("2001:db8:1234:5678::2")).toBe("2001:db8:1234:*");
  });

  it("从常见 User-Agent 归类设备、系统和浏览器", () => {
    expect(classifyVisitorAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1")).toMatchObject({ deviceType: "手机", operatingSystem: "iOS", browser: "Safari" });
    expect(classifyVisitorAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123.0.0.0 Safari/537.36")).toMatchObject({ deviceType: "电脑", operatingSystem: "Windows", browser: "Chrome" });
  });

  it("只显示合法来源 URL 的主机名", () => {
    expect(getReferrerHost("https://www.google.com/search?q=yingzhi")).toBe("www.google.com");
    expect(getReferrerHost("not a url")).toBeNull();
  });

  it("仅从部署层已提供的地区请求头汇总粗略地区线索", () => {
    expect(getCoarseRegionHint({ headers: { "x-appengine-city": "Shanghai", "x-appengine-region": "Shanghai", "x-appengine-country": "CN" } } as never)).toBe("Shanghai · Shanghai · CN");
    expect(getCoarseRegionHint({ headers: {} } as never)).toBeNull();
  });

  it("按连续日期返回每日访客趋势，并为无访问日期补零", () => {
    expect(buildDailyVisitorSeries([{ day: "2026-08-24", visitors: 3, visits: 5 }], new Date("2026-08-25T12:00:00Z"), 3)).toEqual([
      { day: "2026-08-23", label: "8/23", visitors: 0, visits: 0 },
      { day: "2026-08-24", label: "8/24", visitors: 3, visits: 5 },
      { day: "2026-08-25", label: "8/25", visitors: 0, visits: 0 },
    ]);
  });
});
