import type { Request } from "express";
import type { InsertVisitorEvent } from "../drizzle/schema";

function requestHeader(request: Pick<Request, "headers">, name: string): string {
  const value = request.headers[name.toLowerCase()];
  return Array.isArray(value) ? (value[0] ?? "") : (value ?? "");
}

export function maskIpAddress(rawIp: string | undefined): string {
  const source = (rawIp ?? "").trim().split(",")[0]?.trim() || "unknown";
  const ip = source.replace(/^::ffff:/i, "");
  const ipv4 = ip.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.\d{1,3}$/);
  if (ipv4) return `${ipv4[1]}.${ipv4[2]}.${ipv4[3]}.*`;
  if (ip.includes(":")) return `${ip.split(":").slice(0, 3).join(":")}:*`;
  return "unknown";
}

export function classifyVisitorAgent(userAgent: string | undefined) {
  const ua = (userAgent ?? "").toLowerCase();
  const deviceType = /iphone|ipod|android.*mobile|windows phone/.test(ua) ? "手机" : /ipad|tablet|android/.test(ua) ? "平板" : "电脑";
  const operatingSystem = /windows/.test(ua) ? "Windows" : /android/.test(ua) ? "Android" : /iphone|ipad|ipod/.test(ua) ? "iOS" : /mac os|macintosh/.test(ua) ? "macOS" : /linux/.test(ua) ? "Linux" : "未知系统";
  const browser = /edg\//.test(ua) ? "Microsoft Edge" : /opr\//.test(ua) ? "Opera" : /firefox\//.test(ua) ? "Firefox" : /chrome\//.test(ua) ? "Chrome" : /safari\//.test(ua) ? "Safari" : "未知浏览器";
  return { deviceType, operatingSystem, browser };
}

export function getReferrerHost(value: string | undefined): string | null {
  if (!value) return null;
  try { return new URL(value).host.slice(0, 255) || null; } catch { return null; }
}

function firstHeader(request: Pick<Request, "headers">, names: string[]): string {
  return names.map(name => requestHeader(request, name)).find(Boolean) ?? "";
}

export function getCoarseRegionHint(request: Pick<Request, "headers">): string | null {
  const city = firstHeader(request, ["x-appengine-city", "x-vercel-ip-city", "cf-ipcity"]);
  const region = firstHeader(request, ["x-appengine-region", "x-vercel-ip-country-region", "cf-region"]);
  const country = firstHeader(request, ["x-appengine-country", "x-vercel-ip-country", "cf-ipcountry"]);
  const parts = [city, region, country].map(value => value.trim().slice(0, 48)).filter(Boolean);
  return parts.length ? parts.join(" · ").slice(0, 160) : null;
}

export function buildDailyVisitorSeries(rows: Array<{ day: string; visitors: number | string; visits: number | string }>, now = new Date(), days = 7) {
  const values = new Map(rows.map(row => [row.day, { visitors: Number(row.visitors), visits: Number(row.visits) }]));
  const currentDay = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  return Array.from({ length: days }, (_, index) => {
    const date = new Date(currentDay);
    date.setUTCDate(currentDay.getUTCDate() - (days - 1 - index));
    const day = date.toISOString().slice(0, 10);
    const value = values.get(day) ?? { visitors: 0, visits: 0 };
    return { day, label: `${date.getUTCMonth() + 1}/${date.getUTCDate()}`, ...value };
  });
}

export function buildVisitorEvent(request: Pick<Request, "headers" | "socket">, input: { pagePath: string; visitorId: string; timeZone?: string; language?: string }): InsertVisitorEvent {
  const forwarded = requestHeader(request, "x-forwarded-for");
  const ip = forwarded || request.socket.remoteAddress || undefined;
  const agent = classifyVisitorAgent(requestHeader(request, "user-agent"));
  return {
    pagePath: input.pagePath,
    visitorId: input.visitorId,
    maskedIp: maskIpAddress(ip),
    referrerHost: getReferrerHost(requestHeader(request, "referer") || requestHeader(request, "referrer")),
    regionHint: getCoarseRegionHint(request),
    timeZone: input.timeZone?.trim().slice(0, 64) || null,
    language: input.language?.trim().slice(0, 32) || null,
    ...agent,
  };
}
