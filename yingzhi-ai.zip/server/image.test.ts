import { describe, expect, it } from "vitest";
import { GPT_IMAGE_2_MODEL, normalizeImagePrompt } from "./image";

describe("映知 AI 图像生成请求", () => {
  it("使用 GPT Image 2 模型标识", () => {
    expect(GPT_IMAGE_2_MODEL).toBe("MODEL_GPT_IMAGE_2");
  });

  it("会规范化图像提示词中的多余空白", () => {
    expect(normalizeImagePrompt("  极简   蓝色  科技海报  ")).toBe("极简 蓝色 科技海报");
  });
});
