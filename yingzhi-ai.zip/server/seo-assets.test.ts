import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(import.meta.dirname, "..");
const canonicalOrigin = "https://yingzhiai-dz8wmc2y.manus.space";

describe("映知 AI 搜索引擎基础资源", () => {
  it("首页提供映知品牌词、规范链接和组织结构化数据", () => {
    const html = readFileSync(resolve(projectRoot, "client/index.html"), "utf8");
    expect(html).toContain("映知 AI");
    expect(html).toContain("景田科创");
    expect(html).toContain('name="google-site-verification"');
    expect(html).toContain(`<link rel="canonical" href="${canonicalOrigin}/" />`);
    expect(html).toContain('"@type": "Organization"');
    expect(html).toContain('"@type": "SoftwareApplication"');
  });

  it("robots.txt 和 sitemap.xml 指向唯一官网主页", () => {
    const robots = readFileSync(resolve(projectRoot, "client/public/robots.txt"), "utf8");
    const sitemap = readFileSync(resolve(projectRoot, "client/public/sitemap.xml"), "utf8");
    expect(robots).toContain(`Sitemap: ${canonicalOrigin}/sitemap.xml`);
    expect(sitemap).toContain(`<loc>${canonicalOrigin}/</loc>`);
    expect(sitemap).not.toContain("/chat");
    expect(sitemap).not.toContain("/app");
  });
});
