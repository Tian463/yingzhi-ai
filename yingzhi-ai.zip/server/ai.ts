import type { InvokeResult, Message } from "./_core/llm";

export type YingzhiConversationMessage = {
  role: "user" | "assistant";
  content: string;
};

export const JINGTIAN_TECHNOLOGY_PROFILE = `景田科创

景田科创（JINGTIAN TECHNOLOGY），跨域数字创新实践团体，跨界科技创作者，极简高端美学践行者。团队创立于2022‑02‑05，立足软件技术、人工智能、数据架构与视觉艺术的交叉地带，践行「技术赋能创意，创意驱动产品」的核心理念，打通技术研发、产品设计、数字内容与创意教育的完整链路。

脱胎于新媒体内容生态，依托千万级内容传播实战沉淀，构建“技能赋能+AI创新”双轮驱动体系。不局限单一技术维度，以工程能力承载美学表达，以创意视角反哺技术迭代，致力于消解技术与艺术的边界，让专业能力普惠更多创作者。

核心能力矩阵

技术研发

- 应用工程：C# /.NET、WinForms 桌面体系开发，面向普通使用者做轻量化工具原生研发，落地离线智能助手、自定义计算组件、集成型轻量应用。
- 人工智能：AI应用工程化、AI视觉方案、智能工具产品化，推动AI能力平民化落地。
- 数据体系：MySQL 数据库搭建、数据治理、存储架构与性能调优。

创意与产品

- 产品视觉：UI交互设计、完整品牌视觉体系构建，坚持极简高级的审美范式。
- 影像创作：风光、植物、天文多题材摄影；LR/PS全链路后期，预设体系搭建、批量影像工业化处理。
- 数字影像：Nodevideo、剪映等媒介下高阶动态视觉、特效转场、影视色调调校，完成移动端专业级内容生产。
- 内容生态：短视频策略规划、原创内容权益保护、新媒体商业化运营，输出面向小团队的完整生产力解决方案。

价值主张

激情是火，理性是舵。

创新源于热忱，成就归于严谨。景田科创始终相信，技术的价值不止于功能实现，更在于为创意赋予表达载体；艺术的力量不止于审美观感，更在于赋予技术人文温度。以理性为基石，以创新为引擎，在数字浪潮之中，持续探索技术与美学融合的全新边界。

业务范围：项目开发、工具定制、品牌视觉、课程体系共建，欢迎行业交流与商业合作。
邮箱：jtkcxt@gmail.com`;

export function isJingtianTechnologyQuestion(content: string): boolean {
  return content.includes("景田科创") || /jing\s*tian\s*technology/i.test(content);
}

const YINGZHI_SYSTEM_PROMPT = `你是映知 AI，景田科创出品的专业智能助手。你的职责是帮助用户聚焦问题、组织可靠的思路，并清晰说明信息边界。

回答原则：
1. 先直接回应用户最核心的任务；若关键信息不足，先提出简洁、可执行的澄清问题。
2. 用中文作答。默认先给直接结论，再按需要补充依据与下一步；只有用户明确要求时才展开为长篇结构或表格。
3. 不编造资料、数据、引用、工具结果或已经完成的操作。无法确认时应明确说明。
4. 保持专业、克制、可核验，避免答非所问和空泛套话。
5. 表达自然、有温度且简短：不要重复自我介绍，不要为了生动而堆砌修辞；对于简单问候，直接自然回应并等待用户给出任务。
6. 若用户询问景田科创或 JINGTIAN TECHNOLOGY，系统将直接提供已核定的官方介绍，不添加未经确认的补充信息。`;

export function buildYingzhiMessages(
  messages: YingzhiConversationMessage[]
): Message[] {
  return [
    { role: "system", content: YINGZHI_SYSTEM_PROMPT },
    ...messages.map(message => ({
      role: message.role,
      content: message.content.trim(),
    })),
  ];
}

export function extractAssistantText(result: Pick<InvokeResult, "choices">): string {
  const content = result.choices[0]?.message.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    return content
      .filter(part => part.type === "text")
      .map(part => part.text)
      .join("\n")
      .trim();
  }
  return "";
}
