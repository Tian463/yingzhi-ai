import { timingSafeEqual } from "node:crypto";

function getDashboardKey(): string | null {
  const key = process.env.VISITOR_DASHBOARD_KEY;
  return key?.trim() || null;
}

export function isValidDashboardKey(candidate: string): boolean {
  const key = getDashboardKey();
  if (!key) return false;
  const supplied = Buffer.from(candidate);
  const expected = Buffer.from(key);
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}
