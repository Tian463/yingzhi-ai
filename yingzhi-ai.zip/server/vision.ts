import { extractAssistantText } from "./ai";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";

const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
const SUPPORTED_IMAGE_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
]);

const VISION_SYSTEM_PROMPT = `你是映知 AI 的图文解读助手。请基于用户上传的图片和问题，用中文直接给出清晰、可靠的回答。

回答要求：
1. 先概括画面、文字或图表传达的核心信息。
2. 再指出重要细节、可能的歧义或无法从图片确认的部分。
3. 对图片中的文字、数据、人物身份、地点等内容不要臆测；看不清时明确说明。
4. 默认简洁、有条理，用户明确要求时再扩展。`;

type ParsedImage = {
  buffer: Buffer;
  mimeType: string;
  extension: string;
};

function getExtension(mimeType: string) {
  return mimeType === "image/jpeg" ? "jpg" : mimeType.replace("image/", "");
}

export function parseImageDataUrl(dataUrl: string): ParsedImage {
  const matched = /^data:(image\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl);
  if (!matched) throw new Error("图片格式无效，请重新选择 PNG、JPG、WEBP 或 GIF 图片。");

  const mimeType = matched[1].toLowerCase();
  if (!SUPPORTED_IMAGE_MIME_TYPES.has(mimeType)) {
    throw new Error("暂仅支持 PNG、JPG、WEBP 或 GIF 图片。");
  }

  const buffer = Buffer.from(matched[2].replace(/\s/g, ""), "base64");
  if (!buffer.length) throw new Error("图片内容为空，请重新选择文件。");
  if (buffer.byteLength > MAX_IMAGE_BYTES) throw new Error("图片不能超过 20 MB，请压缩后再试。");

  return { buffer, mimeType, extension: getExtension(mimeType) };
}

function cleanFilename(filename: string | undefined) {
  const normalized = (filename ?? "image")
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
  return normalized || "image";
}

export function getRequestOrigin(request: {
  protocol?: string;
  headers: Record<string, string | string[] | undefined>;
}) {
  const forwardedProtocol = request.headers["x-forwarded-proto"];
  const forwardedHost = request.headers["x-forwarded-host"];
  const headerHost = request.headers.host;
  const protocol = (Array.isArray(forwardedProtocol) ? forwardedProtocol[0] : forwardedProtocol)
    ?.split(",")[0]
    .trim() || request.protocol || "https";
  const host = (Array.isArray(forwardedHost) ? forwardedHost[0] : forwardedHost) || (Array.isArray(headerHost) ? headerHost[0] : headerHost);
  return host ? `${protocol}://${host}` : undefined;
}

export async function analyzeUploadedImage(input: {
  dataUrl: string;
  fileName?: string;
  prompt?: string;
  publicOrigin?: string;
}) {
  const image = parseImageDataUrl(input.dataUrl);
  const { url: imageUrl } = await storagePut(
    `user-uploads/visual-analysis/${cleanFilename(input.fileName)}.${image.extension}`,
    image.buffer,
    image.mimeType,
  );
  const visionUrl = input.publicOrigin ? `${input.publicOrigin}${imageUrl}` : input.dataUrl;
  const result = await invokeLLM({
    messages: [
      { role: "system", content: VISION_SYSTEM_PROMPT },
      {
        role: "user",
        content: [
          { type: "text", text: input.prompt?.trim() || "请解读这张图片，先概括核心信息，再指出值得注意的细节。" },
          { type: "image_url", image_url: { url: visionUrl, detail: "high" } },
        ],
      },
    ],
    maxTokens: 1200,
  });
  const answer = extractAssistantText(result);
  if (!answer) throw new Error("模型未返回可呈现的图片解读结果");

  return { answer, imageUrl, model: result.model };
}
