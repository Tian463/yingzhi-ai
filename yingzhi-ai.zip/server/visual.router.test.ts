import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./vision", () => ({
  analyzeUploadedImage: vi.fn(),
  getRequestOrigin: vi.fn(() => "https://yingzhiai.example.com"),
}));

import { analyzeUploadedImage } from "./vision";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const mockedAnalyzeUploadedImage = vi.mocked(analyzeUploadedImage);

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: { host: "yingzhiai.example.com" } } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("visual.analyze", () => {
  beforeEach(() => mockedAnalyzeUploadedImage.mockReset());

  it("上传图片后返回视觉解读与已存储图片地址", async () => {
    mockedAnalyzeUploadedImage.mockResolvedValue({
      answer: "这是一张展示蓝色花朵的图片。",
      imageUrl: "/manus-storage/user-uploads/flower.png",
      model: "vision-model",
    });
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.visual.analyze({
      dataUrl: "data:image/png;base64,QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo=",
      fileName: "flower.png",
      prompt: "这是什么？",
    })).resolves.toEqual({
      answer: "这是一张展示蓝色花朵的图片。",
      imageUrl: "/manus-storage/user-uploads/flower.png",
      model: "vision-model",
    });
    expect(mockedAnalyzeUploadedImage).toHaveBeenCalledWith(expect.objectContaining({
      fileName: "flower.png",
      prompt: "这是什么？",
      publicOrigin: "https://yingzhiai.example.com",
    }));
  });

  it("将视觉服务失败转换为可显示的受控错误", async () => {
    mockedAnalyzeUploadedImage.mockRejectedValueOnce(new Error("图片不能超过 20 MB，请压缩后再试。"));
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.visual.analyze({
      dataUrl: "data:image/png;base64,QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo=",
    })).rejects.toMatchObject({
      code: "INTERNAL_SERVER_ERROR",
      message: "图片不能超过 20 MB，请压缩后再试。",
    });
  });
});
