import { describe, expect, it } from "vitest";
import { canonicalOrigin, robotsTxt, sitemapXml } from "./seo";

describe("映知 AI 生产 SEO 路由内容", () => {
  it("robots.txt 向爬虫开放官网并声明站点地图", () => {
    expect(robotsTxt).toContain("User-agent: *");
    expect(robotsTxt).toContain("Allow: /");
    expect(robotsTxt).toContain(`Sitemap: ${canonicalOrigin}/sitemap.xml`);
  });

  it("sitemap.xml 仅声明可索引的官网首页", () => {
    expect(sitemapXml).toContain('<?xml version="1.0" encoding="UTF-8"?>');
    expect(sitemapXml).toContain(`<loc>${canonicalOrigin}/</loc>`);
    expect(sitemapXml).not.toContain("/chat");
    expect(sitemapXml).not.toContain("/app");
  });
});
