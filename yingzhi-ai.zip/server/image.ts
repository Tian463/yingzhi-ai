import { generateImage } from "./_core/imageGeneration";

export const GPT_IMAGE_2_MODEL = "MODEL_GPT_IMAGE_2";

export function normalizeImagePrompt(prompt: string): string {
  return prompt.trim().replace(/\s+/g, " ");
}

export async function createYingzhiImage(prompt: string) {
  const normalizedPrompt = normalizeImagePrompt(prompt);
  if (!normalizedPrompt) throw new Error("请先描述你想生成的图像");

  return generateImage({
    prompt: normalizedPrompt,
    model: GPT_IMAGE_2_MODEL,
    quality: "medium",
  });
}
