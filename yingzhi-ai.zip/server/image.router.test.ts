import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./image", () => ({
  createYingzhiImage: vi.fn(),
}));

import { createYingzhiImage } from "./image";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const mockedCreateImage = vi.mocked(createYingzhiImage);

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("image.generate", () => {
  beforeEach(() => {
    mockedCreateImage.mockReset();
  });

  it("使用 GPT Image 2 服务返回的 URL 作为图像结果", async () => {
    mockedCreateImage.mockResolvedValue({ url: "https://cdn.example.com/yingzhi-image.png" });
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.image.generate({ prompt: "未来感的蓝色流体标志" })).resolves.toEqual({
      imageUrl: "https://cdn.example.com/yingzhi-image.png",
      model: "gpt-image-2",
    });
    expect(mockedCreateImage).toHaveBeenCalledWith("未来感的蓝色流体标志");
  });

  it("当图像服务失败或没有返回 URL 时，向前端返回受控错误", async () => {
    mockedCreateImage.mockRejectedValueOnce(new Error("upstream unavailable"));
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.image.generate({ prompt: "极简科技海报" })).rejects.toMatchObject({
      code: "INTERNAL_SERVER_ERROR",
      message: "图像生成暂时不可用，请稍后再试。",
    });

    mockedCreateImage.mockResolvedValueOnce({});
    await expect(caller.image.generate({ prompt: "极简科技海报" })).rejects.toMatchObject({
      code: "INTERNAL_SERVER_ERROR",
    });
  });
});
