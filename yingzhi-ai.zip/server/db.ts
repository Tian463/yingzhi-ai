import { count, countDistinct, desc, eq, gte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, InsertVisitorEvent, users, visitorEvents } from "../drizzle/schema";
import { ENV } from './_core/env';
import { buildDailyVisitorSeries } from "./visitorAnalytics";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

function numericValue(value: number | string | null | undefined): number {
  return Number(value ?? 0);
}

export async function recordVisitorEvent(event: InsertVisitorEvent): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(visitorEvents).values(event);
}

export async function getVisitorOverview() {
  const db = await getDb();
  if (!db) {
    return { totalVisits: 0, estimatedVisitors: 0, activeVisitors24Hours: 0, uniqueNetworks: 0, visitsLast24Hours: 0, latestActivity: null, visits: [], pageBreakdown: [], sourceBreakdown: [], regionBreakdown: [], dailyVisitors: buildDailyVisitorSeries([]), deviceBreakdown: [] };
  }

  const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const sevenDaysAgo = new Date(Date.now() - 6 * 24 * 60 * 60 * 1000);
  const [totals, recentTotals, uniqueTotals, uniqueVisitorTotals, activeVisitorTotals, visits, pageBreakdown, sourceBreakdown, regionBreakdown, dailyEvents, deviceBreakdown] = await Promise.all([
    db.select({ value: count() }).from(visitorEvents),
    db.select({ value: count() }).from(visitorEvents).where(gte(visitorEvents.viewedAt, last24Hours)),
    db.select({ value: countDistinct(visitorEvents.maskedIp) }).from(visitorEvents),
    db.select({ value: countDistinct(visitorEvents.visitorId) }).from(visitorEvents),
    db.select({ value: countDistinct(visitorEvents.visitorId) }).from(visitorEvents).where(gte(visitorEvents.viewedAt, last24Hours)),
    db.select().from(visitorEvents).orderBy(desc(visitorEvents.viewedAt)).limit(100),
    db.select({ label: visitorEvents.pagePath, value: count() }).from(visitorEvents).groupBy(visitorEvents.pagePath).orderBy(desc(count())).limit(6),
    db.select({ label: visitorEvents.referrerHost, value: count() }).from(visitorEvents).groupBy(visitorEvents.referrerHost).orderBy(desc(count())).limit(6),
    db.select({ label: visitorEvents.regionHint, value: count() }).from(visitorEvents).groupBy(visitorEvents.regionHint).orderBy(desc(count())).limit(6),
    db.select({ viewedAt: visitorEvents.viewedAt, visitorId: visitorEvents.visitorId }).from(visitorEvents).where(gte(visitorEvents.viewedAt, sevenDaysAgo)),
    db.select({ label: visitorEvents.deviceType, value: count() }).from(visitorEvents).groupBy(visitorEvents.deviceType).orderBy(desc(count())),
  ]);

  const normalizeBreakdown = (rows: Array<{ label: string | null; value: number | string }>, fallback: string) => rows.map(row => ({ label: row.label || fallback, value: numericValue(row.value) }));
  const dailyAccumulator = new Map<string, { visitorIds: Set<string>; visits: number }>();
  for (const event of dailyEvents) {
    const day = event.viewedAt.toISOString().slice(0, 10);
    const current = dailyAccumulator.get(day) ?? { visitorIds: new Set<string>(), visits: 0 };
    current.visitorIds.add(event.visitorId);
    current.visits += 1;
    dailyAccumulator.set(day, current);
  }
  const dailyRows = Array.from(dailyAccumulator, ([day, value]) => ({ day, visitors: value.visitorIds.size, visits: value.visits }));

  return {
    totalVisits: numericValue(totals[0]?.value),
    visitsLast24Hours: numericValue(recentTotals[0]?.value),
    uniqueNetworks: numericValue(uniqueTotals[0]?.value),
    estimatedVisitors: numericValue(uniqueVisitorTotals[0]?.value),
    activeVisitors24Hours: numericValue(activeVisitorTotals[0]?.value),
    latestActivity: visits[0]?.viewedAt ?? null,
    visits,
    pageBreakdown: normalizeBreakdown(pageBreakdown, "未知页面"),
    sourceBreakdown: normalizeBreakdown(sourceBreakdown, "直接访问"),
    regionBreakdown: normalizeBreakdown(regionBreakdown, "未提供地区"),
    dailyVisitors: buildDailyVisitorSeries(dailyRows),
    deviceBreakdown: normalizeBreakdown(deviceBreakdown, "未知设备"),
  };
}
