import { describe, expect, it } from "vitest";
import { getRequestOrigin, parseImageDataUrl } from "./vision";

describe("视觉上传安全校验", () => {
  it("接受受支持的 PNG data URL 并保留二进制内容", () => {
    const image = parseImageDataUrl("data:image/png;base64,aGVsbG8=");
    expect(image.mimeType).toBe("image/png");
    expect(image.extension).toBe("png");
    expect(image.buffer.toString()).toBe("hello");
  });

  it("拒绝不支持的图片格式", () => {
    expect(() => parseImageDataUrl("data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=")).toThrow("暂仅支持");
  });

  it("接受超过 5 MB、但不超过 20 MB 的图片", () => {
    const sixMegabytePayload = Buffer.alloc(6 * 1024 * 1024, 7).toString("base64");
    const image = parseImageDataUrl(`data:image/jpeg;base64,${sixMegabytePayload}`);
    expect(image.buffer.byteLength).toBe(6 * 1024 * 1024);
  });

  it("优先使用反向代理提供的公开来源地址", () => {
    expect(getRequestOrigin({
      protocol: "http",
      headers: { "x-forwarded-proto": "https", "x-forwarded-host": "yingzhiai.example.com" },
    })).toBe("https://yingzhiai.example.com");
  });
});
