import type { Express } from "express";

export const canonicalOrigin = "https://yingzhiai-dz8wmc2y.manus.space";

export const robotsTxt = `User-agent: *
Allow: /

Sitemap: ${canonicalOrigin}/sitemap.xml
`;

export const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${canonicalOrigin}/</loc>
    <lastmod>2026-08-25</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>`;

export function registerSeoRoutes(app: Express) {
  app.get("/robots.txt", (_req, res) => {
    res.type("text/plain").send(robotsTxt);
  });
  app.get("/sitemap.xml", (_req, res) => {
    res.type("application/xml").send(sitemapXml);
  });
}
